using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record CallbackRequest(string EventId, string ProviderRequestId, string Result, DateTimeOffset OccurredAt);
