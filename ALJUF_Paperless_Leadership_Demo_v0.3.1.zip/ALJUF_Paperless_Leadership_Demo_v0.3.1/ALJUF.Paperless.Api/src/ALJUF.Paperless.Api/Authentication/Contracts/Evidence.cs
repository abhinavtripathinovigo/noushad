using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record Evidence(string? OtpCode = null, string? IdentityNumber = null, string? IdLast4 = null);
