using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using System.Text.Encodings.Web;

namespace ALJUF.Paperless;

[ApiController]
public sealed class AuthCallbackController(IPublicAccessService service) : PaperlessControllerBase
{
    [HttpPost("/internal/v1/auth-callbacks/{provider}")]
    [Authorize(Policy = "auth:callback")]
    public async Task<IActionResult> Callback(string provider)
    {
        if (User.FindFirst("provider")?.Value != provider) throw new ApiError(403, "FORBIDDEN", "The provider identity does not match.");
        return new ReplyResult(await service.Callback(provider, await Bodies.Read<CallbackRequest>(HttpContext)));
    }
}
