using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public sealed record RedirectDecision(string Location);
