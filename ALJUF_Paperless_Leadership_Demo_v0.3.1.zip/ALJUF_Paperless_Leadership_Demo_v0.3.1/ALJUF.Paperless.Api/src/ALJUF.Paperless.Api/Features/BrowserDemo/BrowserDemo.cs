using System.Net;
using System.Security.Cryptography;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.DataProtection;
using QRCoder;

namespace ALJUF.Paperless;

public static class BrowserDemo
{
    private static bool Local(HttpContext c) => c.Request.IsHttps &&
        c.Request.Host.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase) &&
        c.Connection.RemoteIpAddress is { } ip && IPAddress.IsLoopback(ip.IsIPv4MappedToIPv6 ? ip.MapToIPv4() : ip);

    public static void MapBrowserDemo(this WebApplication app)
    {
        var settings = app.Services.GetRequiredService<Settings>();
        if (!app.Environment.IsDevelopment() || !settings.EnableDevelopmentFixtures ||
            !app.Configuration.GetValue<bool>("Paperless:BrowserDemo")) return;
        var tickets = app.Services.GetRequiredService<IDataProtectionProvider>().CreateProtector("LocalBrowserDemo.QrTicket.v1").ToTimeLimitedDataProtector();
        app.MapGet("/demo", (HttpContext c, IAntiforgery csrf) =>
        {
            if (!Local(c)) return Results.NotFound();
            var tokens = csrf.GetAndStoreTokens(c);
            var token = Json.Token();
            var ticket = tickets.Protect(token, TimeSpan.FromMinutes(4));
            var url = $"https://{c.Request.Host}/u/{token}";
            using var data = QRCodeGenerator.GenerateQrCode(url, QRCodeGenerator.ECCLevel.M);
            using var qr = new PngByteQRCode(data);
            var png = Convert.ToBase64String(qr.GetGraphic(8));
            return Results.Content($"""
                <!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
                <title>ALJUF | Paperless experience</title><link rel="stylesheet" href="/demo-assets/demo.css"></head><body>
                <header class="topbar"><a class="wordmark" href="/demo" aria-label="ALJUF paperless home">ALJUF<span>FINANCE</span></a><span class="header-divider"></span><span class="product-name">Paperless experience</span><span class="demo-tag"><i></i>Leadership demo</span></header>
                <main class="workspace"><section class="intro"><p class="eyebrow">A simpler document journey</p><h1>From document<br>to digital access.</h1><p class="lead">Turn a PDF into a customer-ready experience.<br class="desktop-break"> Add a QR cover, verify access and open the document.</p></section>
                <ol class="journey" aria-label="Document journey"><li class="current"><span>01</span><div><strong>Prepare</strong><small>Select your document</small></div></li><li><span>02</span><div><strong>Create</strong><small>Add a QR cover page</small></div></li><li><span>03</span><div><strong>Access</strong><small>Verify and view</small></div></li></ol>
                <div class="main-grid"><section class="upload-card" aria-labelledby="upload-title"><div class="card-heading"><div><p class="eyebrow">Start here</p><h2 id="upload-title">Prepare your document</h2></div><span class="format-pill">PDF</span></div>
                <p class="card-description">Choose an unsigned test PDF to create a QR-enabled customer copy.</p>
                <form id="stamp" method="post" action="/demo" enctype="multipart/form-data" data-url="{HtmlEncoder.Default.Encode(url)}" data-qr="{png}" data-max="{settings.MaxFileBytes}">
                <input type="hidden" name="ticket" value="{HtmlEncoder.Default.Encode(ticket)}">
                <input type="hidden" name="{HtmlEncoder.Default.Encode(tokens.FormFieldName)}" value="{HtmlEncoder.Default.Encode(tokens.RequestToken!)}">
                <label class="file-zone" id="file-zone" for="pdf-file"><span class="upload-icon" aria-hidden="true">↑</span><strong id="file-title">Select a PDF document</strong><span id="file-detail">Browse files on this computer</span><span class="browse-label">Choose file</span><input id="pdf-file" type="file" name="file" required accept="application/pdf,.pdf" aria-describedby="file-help"></label>
                <p id="file-help" class="file-help">Unsigned, unencrypted PDF · Maximum {(settings.MaxFileBytes / 1048576d):0.#} MB</p>
                <button class="primary" id="create-button" disabled>Create QR-stamped PDF <span aria-hidden="true">→</span></button><p id="message" class="status-message" role="status" aria-live="polite"></p></form>
                <div class="preserve-note"><span aria-hidden="true">✓</span>Your original file stays unchanged. A QR cover is added to the customer copy.</div><noscript>Enable JavaScript to create the QR-stamped PDF.</noscript></section>
                <aside class="experience-card"><p class="eyebrow">The customer experience</p><h2>One scan.<br>A clear next step.</h2><div class="document-illustration" aria-hidden="true"><div class="document-top"><span>ALJUF</span><span>DOCUMENT</span></div><div class="document-lines"><i></i><i></i><i></i></div><div class="qr-illustration"><b></b><b></b><b></b><span>QR</span></div><div class="document-caption">Your document, digitally accessible</div></div><ul class="benefits"><li><span>01</span>Open the customer link</li><li><span>02</span>Complete identity verification</li><li><span>03</span>View the QR-stamped document</li></ul><div class="demo-note"><strong>For this demonstration</strong><p>The link lasts 5 minutes. Use <b>0123</b> for the test customer’s last four ID digits.</p></div></aside></div>
                <footer class="page-footer"><span>ALJUF Finance <span class="footer-dot">·</span> Paperless document access</span><a href="/swagger">Explore the API in Swagger <span aria-hidden="true">↗</span></a></footer><p class="local-note">Local demonstration · Use synthetic documents. Customer links open on this computer.</p></main>
                <script src="/demo-assets/pdf-lib.min.js"></script><script src="/demo-assets/stamp.js"></script></body></html>
                """, "text/html");
        });
        app.MapPost("/demo", async (HttpContext c, IAntiforgery csrf, UrlCreationWorkflow workflow, TimeProvider clock) =>
        {
            if (!Local(c)) return Results.NotFound();
            if (!c.Request.HasFormContentType) return Results.BadRequest("Choose a PDF using the demo form.");
            await csrf.ValidateRequestAsync(c);
            var form = await c.Request.ReadFormAsync(c.RequestAborted);
            string token;
            try { token = tickets.Unprotect(form["ticket"].ToString()); }
            catch (CryptographicException) { return Results.BadRequest("This demo form has expired or is invalid. Reopen /demo to try again."); }
            var file = form.Files.GetFile("file");
            if (file is null || file.Length < 1 || file.Length > settings.MaxFileBytes)
                return Results.BadRequest("Choose a nonempty test PDF within the configured file size limit.");
            using var stream = file.OpenReadStream();
            var bytes = await FileRules.ReadBounded(stream, settings.MaxFileBytes, c.RequestAborted);
            var request = new CreateUrlRequest(UrlMode.Content, "DEMO_PRIVATE",
                new BusinessReference("LOS", "DEMO", "demo-transaction", Convert.ToHexString(SHA256.HashData(System.Text.Encoding.ASCII.GetBytes(token)))[..32], "r1"),
                "demo-customer", "demo-id4", clock.GetUtcNow().AddMinutes(5), ContentType: "application/pdf",
                FileName: Path.GetFileName(file.FileName), Sha256: Convert.ToHexString(SHA256.HashData(bytes)));
            var reply = await workflow.Create("demo-client", request.BusinessReference.DocumentId, request, bytes, true, c.RequestAborted, token);
            var path = new Uri(reply.Body.GetProperty("publicUrl").GetString()!).AbsolutePath;
            return Results.Content($"""
                <!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ALJUF | Document ready</title><link rel="stylesheet" href="/demo-assets/demo.css"></head><body>
                <header class="topbar"><a class="wordmark" href="/demo">ALJUF<span>FINANCE</span></a><span class="header-divider"></span><span class="product-name">Paperless experience</span><span class="demo-tag"><i></i>Leadership demo</span></header>
                <main class="success-layout"><section class="success-card"><div class="success-icon" aria-hidden="true">✓</div><p class="eyebrow">Ready for the next step</p><h1>Your document.<br>Now connected.</h1><p class="lead">The QR-enabled customer copy is ready.<br>Open the customer page to complete the journey.</p><div class="ready-details"><div><small>Access window</small><strong>5 minutes</strong></div><div><small>Demo verification code</small><strong>0123</strong></div></div><a class="primary" href="{HtmlEncoder.Default.Encode(path)}">Open customer page <span aria-hidden="true">→</span></a><a class="secondary-link" href="/demo">Prepare another document</a><p class="file-help">Use the demo code when asked for the last four ID digits.</p></section><p class="local-note">ALJUF Finance · Local demonstration · Customer links open on this computer.</p></main></body></html>
                """, "text/html");
        });
    }
}
