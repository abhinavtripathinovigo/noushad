namespace ALJUF.Paperless;

public interface ILifecycleService { Task<Reply> Lifecycle(string owner, LifecycleRequest request); }
