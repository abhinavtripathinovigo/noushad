using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using System.Text.Encodings.Web;

namespace ALJUF.Paperless;

[ApiController]
public sealed class LifecycleController(ILifecycleService service) : PaperlessControllerBase
{
    [HttpPost("/internal/v1/lifecycle-events")]
    [Authorize(Policy = "url:lifecycle")]
    public async Task<IActionResult> Receive() => new ReplyResult(await service.Lifecycle(Owner, await Bodies.Read<LifecycleRequest>(HttpContext)));
}
