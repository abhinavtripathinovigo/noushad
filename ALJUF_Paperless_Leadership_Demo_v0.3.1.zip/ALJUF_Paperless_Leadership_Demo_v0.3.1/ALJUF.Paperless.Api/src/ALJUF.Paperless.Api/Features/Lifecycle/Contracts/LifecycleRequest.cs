using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record LifecycleRequest(string EventId, string UrlId, string EventType, long Sequence);
