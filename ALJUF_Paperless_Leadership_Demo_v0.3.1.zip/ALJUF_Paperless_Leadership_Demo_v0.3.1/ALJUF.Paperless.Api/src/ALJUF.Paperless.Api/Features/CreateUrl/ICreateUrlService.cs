namespace ALJUF.Paperless;

public interface ICreateUrlService
{
    Task<Reply> Create(string owner, string key, CreateUrlRequest request, byte[]? file, CancellationToken ct);
}
