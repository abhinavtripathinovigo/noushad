namespace ALJUF.Paperless;
public sealed record ReviewedCreateUrlRequest(UrlMode? Mode, string PurposeCode, BusinessReference BusinessReference,
    SubjectDetails Subject, DateTimeOffset? ExpiresAt = null, int? MaxAccessCount = null, string Locale = "en",
    AuthenticationType AuthenticationType = AuthenticationType.NoAuth, ReviewedTarget? Target = null);
