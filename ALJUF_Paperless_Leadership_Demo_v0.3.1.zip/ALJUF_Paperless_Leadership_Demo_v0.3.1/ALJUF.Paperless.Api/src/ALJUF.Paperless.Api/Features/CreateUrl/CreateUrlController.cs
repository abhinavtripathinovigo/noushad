using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using System.Text.Encodings.Web;

namespace ALJUF.Paperless;

[ApiController]
public sealed class CreateUrlController(ICreateUrlService service, Settings settings) : PaperlessControllerBase
{
    [HttpPost("/v1/urls")]
    [Authorize(Policy = "url:create")]
    public async Task<IActionResult> Create()
    {
        var (request, bytes) = await Bodies.Create(HttpContext, settings.MaxFileBytes);
        return new ReplyResult(await service.Create(Owner, Key, request, bytes, Cancellation));
    }
}
