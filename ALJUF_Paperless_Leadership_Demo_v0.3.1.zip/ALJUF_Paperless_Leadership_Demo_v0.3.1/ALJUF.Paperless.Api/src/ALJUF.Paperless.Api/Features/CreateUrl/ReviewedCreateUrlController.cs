using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace ALJUF.Paperless;
[ApiController]
public sealed class ReviewedCreateUrlController(ReviewedCreateUrlService service) : PaperlessControllerBase
{
    [HttpPost("/v2/urls")][Authorize(Policy="url:create")]
    public async Task<IActionResult> Create() => new ReplyResult(await service.Create(Owner,Key,await Bodies.Read<ReviewedCreateUrlRequest>(HttpContext),Cancellation));
}
