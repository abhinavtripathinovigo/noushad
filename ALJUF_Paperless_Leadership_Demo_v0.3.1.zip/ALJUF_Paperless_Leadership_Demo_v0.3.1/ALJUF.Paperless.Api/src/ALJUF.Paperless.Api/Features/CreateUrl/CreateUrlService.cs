namespace ALJUF.Paperless;

public sealed class CreateUrlService(UrlCreationWorkflow workflow) : ICreateUrlService
{
    public Task<Reply> Create(string owner, string key, CreateUrlRequest request, byte[]? file, CancellationToken ct)
        => workflow.Create(owner, key, request, file, false, ct);
}
