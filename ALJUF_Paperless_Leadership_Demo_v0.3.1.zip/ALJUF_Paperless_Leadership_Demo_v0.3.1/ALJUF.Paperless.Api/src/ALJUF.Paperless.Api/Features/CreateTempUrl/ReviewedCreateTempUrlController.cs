using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace ALJUF.Paperless;
[ApiController]
public sealed class ReviewedCreateTempUrlController(ReviewedTempUrlService service) : PaperlessControllerBase
{
    [HttpPost("/v2/temp-urls")][Authorize(Policy="url:create")]
    public async Task<IActionResult> Create() => new ReplyResult(await service.Create(Owner,Key,await Bodies.Read<ReviewedTempUrlRequest>(HttpContext),Cancellation));
}
