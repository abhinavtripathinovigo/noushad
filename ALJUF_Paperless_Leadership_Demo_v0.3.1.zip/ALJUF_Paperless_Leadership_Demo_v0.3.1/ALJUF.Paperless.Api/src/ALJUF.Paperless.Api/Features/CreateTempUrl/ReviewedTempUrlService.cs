namespace ALJUF.Paperless;
public sealed class ReviewedTempUrlService(Settings settings,UrlPolicyService rules,ReviewedUrlPolicy reviewed)
{
    public Task<Reply> Create(string owner,string key,ReviewedTempUrlRequest request,CancellationToken ct)
        =>rules.Mutation(owner,"V2.Temporary",key,request,async tx=>{
            var parent=rules.Owned(tx,request.UrlId,owner);
            if(parent.Kind!=UrlKind.Regular || parent.Request.Mode==UrlMode.Draft)throw ApiError.Conflict("PARENT_NOT_READY");
            await rules.Gate(parent,ct);
            int minutes=request.ExpireAfterMinutes??settings.TemporaryUrlDefaultMinutes;
            if(minutes<1||minutes>settings.TemporaryUrlMaximumMinutes)throw ApiError.Validation("expireAfterMinutes","INVALID_EXPIRY");
            var now=rules.Now;var expiry=now.AddMinutes(minutes);
            if(parent.ExpiresAt is { } end && end<expiry)expiry=end;
            if(expiry<=now)throw ApiError.Conflict();
            var r=new UrlRecord{Id=Guid.NewGuid().ToString("N"),Owner=owner,PublicToken=Json.Token(),
                Request=parent.Request with{ExpiresAt=expiry},Kind=UrlKind.Temporary,Status=UrlStatus.Active,
                ParentUrlId=parent.Id,ParentVersion=parent.Version,CreatedAt=now,UpdatedAt=now,ExpiresAt=expiry,
                AuthenticationType=parent.AuthenticationType,ContentId=parent.ContentId,Content=parent.Content};
            rules.Save(tx,r);tx.Audit.Append("TemporaryCreated",r.Id,owner,now);
            return Reply.Of(201,new ReviewedTempUrlResource(r.Id,reviewed.Resource(r).PublicUrl,r.Kind,now,now,expiry,r.Version),
                UrlPolicyService.ETag(r),"/v2/urls/"+r.Id);
        });
}
