namespace ALJUF.Paperless;
public sealed class ReviewedUpdateUrlService(UrlPolicyService rules,ReviewedUrlPolicy reviewed,TargetResolver targets)
{
    public Task<Reply> Update(string owner,string key,string? etag,ReviewedUpdateUrlRequest request,CancellationToken ct)
        => rules.Mutation(owner,"V2.Update",key,new{request,etag},async tx=>{
            var r=rules.Owned(tx,request.UrlId,owner);UrlPolicyService.Precondition(r,etag);
            if(r.Kind!=UrlKind.Regular || rules.Effective(r) is UrlStatus.Expired or UrlStatus.Revoked) throw ApiError.Conflict();
            bool contentChange=request.Target is not null || request.Mode is not null || request.DocumentRevision is not null;
            if(!contentChange && request.Status is null) throw ApiError.Validation("body","EMPTY_UPDATE");
            if(request.Status is not null && request.Status is not (UrlStatus.Active or UrlStatus.Inactive)) throw ApiError.Validation("status");
            if(contentChange)
            {
                if(rules.Purpose(r.Request.PurposeCode).Immutable && r.Request.Mode!=UrlMode.Draft) throw ApiError.Conflict("IMMUTABLE_RESOURCE");
                UrlPolicyService.Text(request.DocumentRevision,"documentRevision");
                var mode=request.Mode??r.Request.Mode!.Value;
                if(mode==UrlMode.Draft) throw ApiError.Conflict("DRAFT_TRANSITION_NOT_ALLOWED");
                var (target,content)=reviewed.Target(mode,request.Target);
                r.Request=r.Request with{Mode=mode,Target=target,
                    BusinessReference=r.Request.BusinessReference with{DocumentRevision=request.DocumentRevision!},
                    ContentType=content?.ContentType,FileName=content?.FileName,Sha256=content?.Sha256};
                await rules.Domain(r.Request,owner,ct);await reviewed.StoreContent(tx,r,content,ct);
            }
            else {UrlPolicyService.Text(request.ReasonCode,"reasonCode",48);
                if(request.ReasonCode!.Any(c=>!char.IsAsciiLetterOrDigit(c)&&c!='_'))throw ApiError.Validation("reasonCode");}
            if(request.Status==UrlStatus.Active)
            {
                if(r.Request.Mode==UrlMode.Draft) throw ApiError.Conflict("DRAFT_NOT_READY");
                if(r.Request.Mode!=UrlMode.Content) targets.Validate(r.Request.Mode!.Value,r.Request.Target);
                await rules.Domain(r.Request,owner,ct);
            }
            if(request.Status is { } status)r.Status=status;
            rules.Bump(tx,r,"ReviewedUrlUpdated");return reviewed.Reply(r);
        });
}
