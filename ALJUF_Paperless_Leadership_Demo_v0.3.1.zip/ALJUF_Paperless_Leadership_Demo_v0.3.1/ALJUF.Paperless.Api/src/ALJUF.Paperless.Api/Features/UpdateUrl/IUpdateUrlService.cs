namespace ALJUF.Paperless;

public interface IUpdateUrlService
{
    Task<Reply> UpdateTarget(string owner, string id, string key, string? etag, TargetUpdate request, CancellationToken ct);
    Task<Reply> UpdateContent(string owner, string id, string key, string? etag, ContentUpdate request, byte[] bytes, CancellationToken ct);
    Task<Reply> UpdateStatus(string owner, string id, string key, string? etag, StatusUpdate request, CancellationToken ct);
}
