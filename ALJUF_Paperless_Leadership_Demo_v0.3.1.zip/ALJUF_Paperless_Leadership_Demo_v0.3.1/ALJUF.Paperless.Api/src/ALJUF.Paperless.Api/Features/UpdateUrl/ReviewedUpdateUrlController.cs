using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace ALJUF.Paperless;
[ApiController]
public sealed class ReviewedUpdateUrlController(ReviewedUpdateUrlService service) : PaperlessControllerBase
{
    [HttpPatch("/v2/urls")][Authorize(Policy="url:update")]
    public async Task<IActionResult> Update() => new ReplyResult(await service.Update(Owner,Key,Request.Headers.IfMatch,await Bodies.Read<ReviewedUpdateUrlRequest>(HttpContext),Cancellation));
}
