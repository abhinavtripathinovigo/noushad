using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Antiforgery;
using System.Text.Encodings.Web;

namespace ALJUF.Paperless;

[ApiController]
public sealed class PublicAccessController(IPublicAccessService service, IAntiforgery antiforgery, Settings settings, IWebHostEnvironment environment) : PaperlessControllerBase
{
    [HttpGet("/u/{token}")]
    [HttpGet("/t/{token}")]
    public async Task<IActionResult> Landing(string token)
    {
        await service.Landing(token, Cancellation);
        var tokens = antiforgery.GetAndStoreTokens(HttpContext);
        var html = await System.IO.File.ReadAllTextAsync(Path.Combine(environment.ContentRootPath, "Pages", "access.html"), Cancellation);
        return Content(html.Replace("{{CSRF}}", HtmlEncoder.Default.Encode(tokens.RequestToken!)), "text/html; charset=utf-8");
    }

    [HttpPost("/public/v1/access-sessions")]
    public async Task<IActionResult> Start()
    {
        await BrowserGuard();
        var binding = Request.Cookies["__Host-ALJUF-csrf"] ?? throw ApiError.Missing();
        return new ReplyResult(await service.Start(await Bodies.Read<AccessRequest>(HttpContext), Key, binding, Cancellation));
    }

    [HttpPost("/public/v1/access-sessions/{id}/verify")]
    public async Task<IActionResult> Verify(string id)
    {
        await BrowserGuard();
        return new ReplyResult(await service.Verify(id, Request.Cookies[PublicAccessService.FlowCookie(id)], Key,
            await Bodies.Read<VerifyRequest>(HttpContext), Cancellation));
    }

    [HttpGet("/public/v1/access-sessions/{id}")]
    public async Task<IActionResult> Status(string id)
        => new ReplyResult(await service.Status(id, Request.Cookies[PublicAccessService.FlowCookie(id)], Cancellation));

    [HttpGet("/public/v1/access-sessions/{id}/resource")]
    public async Task<IActionResult> Download(string id)
    {
        var resource = await service.Download(id, Request.Cookies[PublicAccessService.FlowCookie(id)],
            Request.Cookies[PublicAccessService.AuthCookie(id)], Cancellation);
        if (resource.Redirect is not null) { Response.Headers.Location = resource.Redirect; return StatusCode(303); }
        return File(resource.Bytes!, "application/pdf", resource.FileName, enableRangeProcessing: false);
    }

    private async Task BrowserGuard()
    {
        if (Request.Headers.Origin != settings.PublicOrigin.TrimEnd('/'))
            throw new ApiError(403, "FORBIDDEN", "The browser origin is not allowed.");
        await antiforgery.ValidateRequestAsync(HttpContext);
    }
}
