using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record AccessSession(string SessionId, SessionState State, AuthenticationType AuthenticationType,
    DateTimeOffset ExpiresAt, string NextAction, int? RemainingAttempts);
