namespace ALJUF.Paperless;

public sealed record ResourceDownload(byte[]? Bytes, string? Redirect, string FileName);
