namespace ALJUF.Paperless;


public sealed class PublicAccessService(IUnitOfWork store, UrlPolicyService urls, Settings settings, IIntegrations integrations, TargetResolver targets) : IPublicAccessService
{
    public static string FlowCookie(string id) => "__Host-ALJUF-flow-" + id;
    public static string AuthCookie(string id) => "__Host-ALJUF-auth-" + id;
    private UrlRecord ByToken(IRepositoryContext tx, string token)
    {
        if (token.Length != 64 || token.Any(c => !char.IsAsciiHexDigit(c))) throw ApiError.Missing();
        return tx.Urls.FindByTokenHash(Json.Hash(token)).SingleOrDefault() ?? throw ApiError.Missing();
    }
    public async Task Landing(string token, CancellationToken ct)
    {
        var r = store.Read(tx => ByToken(tx, token)); await urls.Gate(r, ct);
    }
    private UrlRecord Root(UrlRecord r)=>r.ParentUrlId is null?r:store.Read(tx=>tx.Urls.Get(r.ParentUrlId))??throw ApiError.Missing();
    private void Fail(IRepositoryContext tx,UrlRecord r)
    {
        var root=r.ParentUrlId is null?r:tx.Urls.Get(r.ParentUrlId)??throw ApiError.Missing();
        root.FailedAttempts++;urls.Save(tx,root);r.FailedAttempts=root.FailedAttempts;
    }
    private void Attempts(UrlRecord r)
    {
        r=Root(r);
        if (r.FailedAttempts >= urls.Auth(r.Request.AuthPolicyId).MaxAttempts)
            throw new ApiError(429, "RATE_LIMITED", "Authentication is temporarily unavailable for this link.");
    }
    public Task<Reply> Start(AccessRequest request, string key, string browserBinding, CancellationToken ct)
        => urls.Mutation("browser:" + Json.Hash(browserBinding), "PA02", key, request, async tx =>
        {
            if (request.Locale is not ("ar" or "en")) throw ApiError.Validation("locale");
            if (request.Token is null) throw ApiError.Validation("token");
            var url = ByToken(tx, request.Token); await urls.Gate(url, ct); Attempts(url);
            var policy = urls.Auth(url.Request.AuthPolicyId);
            var decision = policy.Type == AuthenticationType.NoAuth
                ? new AuthenticationDecision(SessionState.Authorized)
                : await integrations.Start(url, policy, Json.Hash(browserBinding + ":" + key), ct);
            // Non-NoAuth initiation cannot authorize a customer. Only verified evidence/callback can.
            if (policy.Type != AuthenticationType.NoAuth && decision.State is not (SessionState.ChallengeRequired or SessionState.Pending))
                throw ApiError.Unavailable();
            if (policy.Type != AuthenticationType.NoAuth && string.IsNullOrWhiteSpace(decision.ProviderRequestId)) throw ApiError.Unavailable();
            var flow = Json.Token();
            var expires = urls.Now.AddSeconds(settings.SessionSeconds);
            if (url.ExpiresAt < expires) expires = url.ExpiresAt.Value;
            var session = new SessionRecord
            {
                Id = Guid.NewGuid().ToString("N"), UrlId = url.Id, UrlVersion = url.Version, FlowHash = Json.Hash(flow),
                State = decision.State, Method = policy.Type, ProviderRequestId = decision.ProviderRequestId,
                Provider = policy.Provider, ExpiresAt = expires, Locale = request.Locale
            };
            var cookies = new List<CookieValue> { new(FlowCookie(session.Id), flow, expires) };
            AuthorizeCookie(session, cookies);
            Save(tx, session); tx.Audit.Append("AccessStarted", url.Id, "public", urls.Now);
            return Reply.Of(201, View(session, url), cookies: cookies);
        });
    private static void Save(IRepositoryContext tx, SessionRecord s) => tx.Sessions.Save(s);
    private static void AuthorizeCookie(SessionRecord s, List<CookieValue> cookies)
    {
        if (s.State != SessionState.Authorized) return;
        var secret = Json.Token(); s.AuthorizedHash = Json.Hash(secret);
        cookies.Add(new(AuthCookie(s.Id), secret, s.ExpiresAt));
    }
    private AccessSession View(SessionRecord s, UrlRecord u) => new(s.Id, s.State, s.Method, s.ExpiresAt,
        s.State switch
        {
            SessionState.Authorized => "OpenResource",
            SessionState.Pending => "ApproveInProviderApp",
            SessionState.ChallengeRequired => s.Method switch
            {
                AuthenticationType.OTP or AuthenticationType.AbsherOTP => "EnterOTP",
                AuthenticationType.IDVerify => "EnterID",
                AuthenticationType.IDVerify4Digit => "EnterLast4",
                _ => "None"
            },
            _ => "None"
        }, s.Method == AuthenticationType.NoAuth ? null : Math.Max(0, urls.Auth(u.Request.AuthPolicyId).MaxAttempts - Math.Max(u.FailedAttempts,Root(u).FailedAttempts)));
    private async Task<(SessionRecord, UrlRecord)> Bound(IRepositoryContext tx, string id, string? cookie, CancellationToken ct)
    {
        var s = tx.Sessions.Get(id) ?? throw ApiError.Missing();
        if (cookie is null || !Json.Equal(s.FlowHash, Json.Hash(cookie))) throw ApiError.Missing();
        if (s.ExpiresAt <= urls.Now) throw new ApiError(410, "EXPIRED_OR_UNAVAILABLE", "The session has expired.");
        var u = tx.Urls.Get(s.UrlId) ?? throw ApiError.Missing();
        await urls.Gate(u, ct);
        if (u.Version != s.UrlVersion) throw ApiError.Missing();
        return (s, u);
    }
    public Task<Reply> Verify(string id, string? cookie, string key, VerifyRequest request, CancellationToken ct)
        => urls.Mutation("flow:" + id + ":" + Json.Hash(cookie ?? ""), "PA03", key, request, async tx =>
        {
            var (s, u) = await Bound(tx, id, cookie, ct); Attempts(u);
            if (s.State != SessionState.ChallengeRequired) throw ApiError.Conflict();
            var evidence = request.Evidence ?? throw ApiError.Validation("evidence");
            switch (s.Method)
            {
                case AuthenticationType.IDVerify4Digit:
                    if (evidence.IdLast4?.Length != 4 || !evidence.IdLast4.All(char.IsAsciiDigit) || evidence.OtpCode is not null || evidence.IdentityNumber is not null)
                        throw ApiError.Validation("evidence");
                    break;
                case AuthenticationType.OTP: case AuthenticationType.AbsherOTP:
                    UrlPolicyService.Text(evidence.OtpCode, "evidence.otpCode", 32);
                    if (evidence.IdLast4 is not null || evidence.IdentityNumber is not null) throw ApiError.Validation("evidence");
                    break;
                case AuthenticationType.IDVerify:
                    UrlPolicyService.Text(evidence.IdentityNumber, "evidence.identityNumber", 32);
                    if (evidence.IdLast4 is not null || evidence.OtpCode is not null) throw ApiError.Validation("evidence");
                    break;
                default: throw ApiError.Conflict();
            }
            var decision = await integrations.Verify(u, s, evidence, Json.Hash(id + ":" + key), ct);
            if (decision.State is not (SessionState.Authorized or SessionState.Denied)) throw ApiError.Unavailable();
            if (decision.State == SessionState.Authorized) s.State = SessionState.Authorized;
            else
            {
                Fail(tx,u);
                s.State = u.FailedAttempts >= urls.Auth(u.Request.AuthPolicyId).MaxAttempts ? SessionState.Denied : SessionState.ChallengeRequired;
            }
            var cookies = new List<CookieValue>(); AuthorizeCookie(s, cookies); Save(tx, s);
            tx.Audit.Append(s.State == SessionState.Authorized ? "AuthenticationSucceeded" : "AuthenticationFailed", u.Id, "public", urls.Now);
            return Reply.Of(200, View(s, u), cookies: cookies);
        });
    public Task<Reply> Status(string id, string? cookie, CancellationToken ct) => store.Write(async tx =>
    {
        var (s, u) = await Bound(tx, id, cookie, ct);
        var cookies = new List<CookieValue>();
        // Callback approval deliberately issues browser credentials only to the original flow.
        if (s.State == SessionState.Authorized) { AuthorizeCookie(s, cookies); Save(tx, s); }
        return Reply.Of(200, View(s, u), cookies: cookies);
    });
    public Task<Reply> Callback(string provider, CallbackRequest request)
        => urls.Mutation("provider:" + provider, "PA06", request.EventId, request, async tx =>
        {
            UrlPolicyService.Text(request.ProviderRequestId, "providerRequestId");
            if (request.Result is not ("Approved" or "Denied" or "Expired")) throw ApiError.Validation("result");
            if (request.OccurredAt.Offset != TimeSpan.Zero || request.OccurredAt > urls.Now.AddMinutes(1) || request.OccurredAt < urls.Now.AddMinutes(-10))
                throw ApiError.Validation("occurredAt");
            var s = tx.Sessions.FindByProviderHash(Json.Hash(provider + ":" + request.ProviderRequestId)).SingleOrDefault() ?? throw ApiError.Missing();
            if (s.State != SessionState.Pending || s.ExpiresAt <= urls.Now) return Reply.Of(204, new { });
            var u = tx.Urls.Get(s.UrlId) ?? throw ApiError.Missing();
            await urls.Gate(u, CancellationToken.None);
            if (s.UrlVersion != u.Version) return Reply.Of(204, new { });
            Attempts(u);
            s.State = request.Result switch { "Approved" => SessionState.Authorized, "Denied" => SessionState.Denied, _ => SessionState.Expired };
            if (s.State == SessionState.Denied) { Fail(tx,u); }
            Save(tx, s); tx.Audit.Append("AuthenticationCallback", u.Id, provider, urls.Now);
            return Reply.Of(204, new { });
        });
    public async Task<ResourceDownload> Download(string id, string? flow, string? authorized, CancellationToken ct)
    {
        var result = await store.Write(async tx =>
        {
            var (s, u) = await Bound(tx, id, flow, ct);
            if (s.State != SessionState.Authorized || authorized is null || s.AuthorizedHash is null || !Json.Equal(s.AuthorizedHash, Json.Hash(authorized)))
                throw new ApiError(401, "UNAUTHENTICATED", "Authentication is required.");
            tx.Audit.Append("DocumentAccess", u.Id, "public", urls.Now);
            return (url: u, expiresAt: s.ExpiresAt, bytes: u.ContentId is null ? null : tx.Content.Get(u.ContentId));
        });
        if (result.url.Request.Mode == UrlMode.Content)
        {
            var bytes=result.bytes??throw ApiError.Unavailable();
            await CountAccess(id,flow,authorized,result.url,ct);
            return new(bytes,null,result.url.Request.FileName??"Document.pdf");
        }
        if (result.url.Request.Mode == UrlMode.RewriteUrl)
        {
            var bytes = await targets.Fetch(result.url, ct);
            // A registered document backend must still return a PDF envelope, not arbitrary HTML.
            if (!bytes.AsSpan().StartsWith("%PDF-"u8)) throw ApiError.Validation("backend.content", "INVALID_CONTENT");
            await EnsureUnchanged(result.url, ct);
            await CountAccess(id,flow,authorized,result.url,ct);
            return new(bytes, null, "Document.pdf");
        }
        var destination = targets.Validate(result.url.Request.Mode!.Value, result.url.Request.Target).AbsoluteUri;
        var redirect = await integrations.Redirect(result.url, destination, result.expiresAt, ct);
        var granted = targets.Redirect(redirect.Location);
        // Grant exchange may append a scoped query but must not silently change the target path or host.
        var expected = new Uri(destination);
        if (granted.GetLeftPart(UriPartial.Path) != expected.GetLeftPart(UriPartial.Path)) throw ApiError.Unavailable();
        await EnsureUnchanged(result.url, ct);
        await CountAccess(id,flow,authorized,result.url,ct);
        return new(null, granted.AbsoluteUri, "");
    }
    private Task CountAccess(string id,string? flow,string? authorized,UrlRecord expected,CancellationToken ct)
        =>store.Write(async tx=>{
            var (s,u)=await Bound(tx,id,flow,ct);
            if(u.Version!=expected.Version || s.State!=SessionState.Authorized || authorized is null
                || s.AuthorizedHash is null || !Json.Equal(s.AuthorizedHash,Json.Hash(authorized)))throw ApiError.Missing();
            var root=u.ParentUrlId is null?u:tx.Urls.Get(u.ParentUrlId)??throw ApiError.Missing();
            if(root.Request.MaxAccessCount is { } max && root.AccessCount>=max)throw ApiError.Missing();
            root.AccessCount++;urls.Save(tx,root);return 0;
        });
    private async Task EnsureUnchanged(UrlRecord old, CancellationToken ct)
    {
        var current = store.Read(tx => tx.Urls.Get(old.Id)) ?? throw ApiError.Missing();
        if (old.Version != current.Version) throw ApiError.Missing();
        await urls.Gate(current, ct);
    }
}
