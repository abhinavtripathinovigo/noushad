using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
namespace ALJUF.Paperless;
[ApiController]
public sealed class ReviewedMetadataController(IUnitOfWork store,UrlPolicyService rules,ReviewedUrlPolicy reviewed):PaperlessControllerBase
{
    [HttpGet("/v2/urls/{id}")][Authorize(Policy="url:read")]
    public IActionResult Get(string id)=>new ReplyResult(store.Read(tx=>reviewed.Reply(rules.Owned(tx,id,Owner))));
}
