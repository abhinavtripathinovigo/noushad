namespace ALJUF.Paperless;

public interface IGenerateQrService { Task<(byte[] Bytes, string ContentType)> Generate(string owner, QrRequest request, CancellationToken ct); }
