namespace ALJUF.Paperless;

public sealed class UrlCreationWorkflow(UrlPolicyService policies, Settings settings, IIntegrations integrations, TargetResolver targets)
{
    private void ValidateRequest(CreateUrlRequest r)
    {
        if (r.Mode is null) throw ApiError.Validation("mode");
        if (r.BusinessReference is null) throw ApiError.Validation("businessReference");
        UrlPolicyService.Text(r.BusinessReference.System, "businessReference.system"); UrlPolicyService.Text(r.BusinessReference.EntityType, "businessReference.entityType");
        UrlPolicyService.Text(r.BusinessReference.EntityId, "businessReference.entityId"); UrlPolicyService.Text(r.BusinessReference.DocumentId, "businessReference.documentId");
        UrlPolicyService.Text(r.BusinessReference.DocumentRevision, "businessReference.documentRevision");
        if (r.Locale is not ("ar" or "en")) throw ApiError.Validation("locale");
        var purpose = policies.Purpose(r.PurposeCode); var auth = policies.Auth(r.AuthPolicyId);
        if (!purpose.AuthPolicies.Contains(r.AuthPolicyId) || (auth.Type == AuthenticationType.NoAuth && !purpose.Anonymous))
            throw ApiError.Validation("authPolicyId", "AUTH_POLICY_NOT_ALLOWED");
        if (purpose.CustomerBound) UrlPolicyService.Text(r.SubjectRef, "subjectRef");
        if (r.Mode == UrlMode.Content)
        {
            if (r.Target is not null) throw ApiError.Validation("target");
        }
        else
        {
            targets.Validate(r.Mode.Value, r.Target);
            if (r.ContentType is not null || r.FileName is not null || r.Sha256 is not null) throw ApiError.Validation("content");
        }
    }
    public Task<Reply> Create(string owner, string key, CreateUrlRequest request, byte[]? file, bool temporary, CancellationToken ct, string? serverIssuedToken = null)
        => policies.Mutation(owner, temporary ? "TU01" : "CU", key, new { request, digest = file is null ? null : Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(file)) }, async tx =>
        {
            ValidateRequest(request);
            var domain = await policies.Domain(request, owner, ct); var policy = policies.Purpose(request.PurposeCode);
            if (temporary && request.ExpiresAt is null) throw ApiError.Validation("expiresAt", "INVALID_EXPIRY");
            var expiry = request.ExpiresAt;
            if (policy.ReceiptTenYears)
            {
                if (temporary || domain.IssuedAt is null) throw ApiError.Validation("expiresAt", "INVALID_EXPIRY");
                var receiptExpiry = domain.IssuedAt.Value.AddYears(10);
                if (expiry is not null && expiry != receiptExpiry) throw ApiError.Validation("expiresAt", "INVALID_EXPIRY");
                expiry = receiptExpiry;
            }
            else if (expiry is null && policy.DefaultExpirySeconds is { } seconds) expiry = policies.Now.AddSeconds(seconds);
            if (expiry is not null && (expiry <= policies.Now || expiry.Value.Offset != TimeSpan.Zero ||
                (policy.MaximumExpirySeconds is { } max && expiry > policies.Now.AddSeconds(max)))) throw ApiError.Validation("expiresAt", "INVALID_EXPIRY");
            // Opaque references are indexed by a hash; the business binding itself is protected in Payload.
            var binding = Json.Hash(Json.Encode(new { owner, request.PurposeCode, request.BusinessReference.System,
                request.BusinessReference.EntityType, request.BusinessReference.EntityId, request.BusinessReference.DocumentId,
                request.BusinessReference.DocumentRevision, kind = temporary ? "Temporary" : "Regular" }));
            var duplicates = tx.Urls.FindByBinding(binding);
            if (duplicates.Any(r => !temporary || policies.Effective(r) is UrlStatus.Active or UrlStatus.Inactive)) throw ApiError.Conflict("DUPLICATE_BINDING");
            var now = policies.Now;
            var resource = new UrlRecord
            {
                Id = Guid.NewGuid().ToString("N"), Owner = owner, PublicToken = serverIssuedToken ?? Json.Token(), Binding = binding,
                Request = request, Kind = temporary ? UrlKind.Temporary : UrlKind.Regular, CreatedAt = now, UpdatedAt = now,
                ExpiresAt = expiry, AuthenticationType = policies.Auth(request.AuthPolicyId).Type
            };
            if (request.Mode == UrlMode.Content)
            {
                var sha = FileRules.Validate(file, request.ContentType, request.FileName, request.Sha256, settings.MaxFileBytes);
                await integrations.Scan(file!, sha, ct);
                resource.ContentId = Guid.NewGuid().ToString("N"); resource.Content = new("application/pdf", file!.Length, sha);
                tx.Content.Save(resource.ContentId, file);
            }
            else if (file is not null) throw ApiError.Validation("file");
            policies.Save(tx, resource);
            tx.Audit.Append("Created", resource.Id, owner, policies.Now);
            return Reply.Of(201, policies.Resource(resource), UrlPolicyService.ETag(resource), "/v1/urls/" + resource.Id);
        });
}
