using System.Net;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Options;
using ALJUF.Paperless;

public static class Bodies
{
    public static async Task<T> Read<T>(HttpContext c)
    {
        if (!c.Request.HasJsonContentType()) throw new ApiError(415, "UNSUPPORTED_MEDIA_TYPE", "Use application/json.");
        var bytes = await FileRules.ReadBounded(c.Request.Body, typeof(T) == typeof(ReviewedCreateUrlRequest) || typeof(T) == typeof(ReviewedUpdateUrlRequest) ? checked(c.RequestServices.GetRequiredService<Settings>().MaxFileBytes * 4 / 3 + 65536) : 32768, c.RequestAborted);
        return Json.Decode<T>(System.Text.Encoding.UTF8.GetString(bytes));
    }
    public static async Task<(CreateUrlRequest, byte[]?)> Create(HttpContext c, int max)
    {
        if (c.Request.HasFormContentType) { var (metadata, file) = await Multipart<CreateUrlRequest>(c, max); return (metadata, file); }
        return (await Read<CreateUrlRequest>(c), null);
    }
    public static async Task<(T, byte[])> Multipart<T>(HttpContext c, int max)
    {
        if (c.Request.ContentType?.StartsWith("multipart/form-data", StringComparison.OrdinalIgnoreCase) != true)
            throw new ApiError(415, "UNSUPPORTED_MEDIA_TYPE", "Use multipart/form-data.");
        var form = await c.Request.ReadFormAsync(c.RequestAborted);
        if (form.Keys.Count() != 1 || !form.ContainsKey("metadata") || form["metadata"].Count != 1 || form.Files.Count != 1 || form.Files[0].Name != "file")
            throw ApiError.Validation("multipart");
        var metadata = Json.Decode<T>(form["metadata"].ToString());
        await using var stream = form.Files[0].OpenReadStream();
        return (metadata, await FileRules.ReadBounded(stream, max, c.RequestAborted));
    }
}
