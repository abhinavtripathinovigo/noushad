using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record Reply(int Status, JsonElement Body, string? ETag = null, string? Location = null, List<CookieValue>? Cookies = null)
{
    public static Reply Of<T>(int status, T body, string? etag = null, string? location = null, List<CookieValue>? cookies = null)
        => new(status, JsonSerializer.SerializeToElement(body, Json.Options), etag, location, cookies);
}
