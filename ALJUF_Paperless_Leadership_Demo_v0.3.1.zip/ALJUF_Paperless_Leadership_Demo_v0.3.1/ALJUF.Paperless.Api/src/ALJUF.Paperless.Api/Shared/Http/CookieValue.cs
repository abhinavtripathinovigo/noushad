using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record CookieValue(string Name, string Value, DateTimeOffset ExpiresAt);
