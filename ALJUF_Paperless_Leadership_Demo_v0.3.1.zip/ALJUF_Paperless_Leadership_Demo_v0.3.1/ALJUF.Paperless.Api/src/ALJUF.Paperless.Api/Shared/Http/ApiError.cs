using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed class ApiError(int status, string code, string message, string? field = null) : Exception(message)
{
    public int Status { get; } = status;
    public string Code { get; } = code;
    public string? Field { get; } = field;
    public static ApiError Validation(string field, string code = "VALIDATION_FAILED") => new(422, code, "The request contains an invalid value.", field);
    public static ApiError Missing() => new(404, "NOT_FOUND", "The resource is unavailable.");
    public static ApiError Unavailable() => new(503, "DEPENDENCY_UNAVAILABLE", "The service is temporarily unavailable.");
    public static ApiError Conflict(string code = "INVALID_STATE") => new(409, code, "The operation is not permitted for the current resource.");
}
