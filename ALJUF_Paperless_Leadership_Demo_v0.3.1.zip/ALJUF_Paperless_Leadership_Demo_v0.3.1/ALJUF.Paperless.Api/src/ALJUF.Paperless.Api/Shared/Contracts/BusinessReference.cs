using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record BusinessReference(string System, string EntityType, string EntityId, string DocumentId, string DocumentRevision);
