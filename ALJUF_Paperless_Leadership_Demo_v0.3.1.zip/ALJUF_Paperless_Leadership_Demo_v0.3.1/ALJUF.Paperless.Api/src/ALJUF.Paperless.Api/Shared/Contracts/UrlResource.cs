using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed record UrlResource(string UrlId, string PublicUrl, UrlKind Kind, UrlMode Mode, UrlStatus Status,
    string PurposeCode, BusinessReference BusinessReference, AuthenticationType AuthenticationType,
    DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt, DateTimeOffset? ExpiresAt, long Version, ContentMetadata? Content);
