namespace ALJUF.Paperless;
public sealed record InlineContent(string Base64, string ContentType, string FileName, string Sha256);
