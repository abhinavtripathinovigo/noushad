using System.Security.Cryptography;
namespace ALJUF.Paperless;
public sealed class ReviewedUrlPolicy(Settings settings, UrlPolicyService rules, TargetResolver targets, IIntegrations integrations)
{
    public ReviewedUrlResource Resource(UrlRecord r) => new(r.Id, settings.PublicOrigin.TrimEnd('/')+(r.ParentUrlId is null?"/u/":"/t/")+r.PublicToken,
        r.Kind, r.Request.Mode!.Value, rules.Effective(r), r.Request.PurposeCode, r.Request.BusinessReference,
        r.AuthenticationType, r.CreatedAt, r.UpdatedAt, r.ExpiresAt, r.Version, r.ParentUrlId);
    public Reply Reply(UrlRecord r, int status = 200) => ALJUF.Paperless.Reply.Of(status, Resource(r), UrlPolicyService.ETag(r), status==201 ? "/v2/urls/"+r.Id : null);
    public async Task<CreateUrlRequest> Normalize(ReviewedCreateUrlRequest r, string owner, CancellationToken ct)
    {
        if (r.Mode is null || !Enum.IsDefined(r.Mode.Value)) throw ApiError.Validation("mode");
        if (r.BusinessReference is null) throw ApiError.Validation("businessReference");
        UrlPolicyService.Text(r.PurposeCode,"purposeCode");
        foreach(var (value,field) in new[]{(r.BusinessReference.System,"system"),(r.BusinessReference.EntityType,"entityType"),
            (r.BusinessReference.EntityId,"entityId"),(r.BusinessReference.DocumentId,"documentId"),(r.BusinessReference.DocumentRevision,"documentRevision")})
            UrlPolicyService.Text(value,"businessReference."+field);
        if(r.Subject is null) throw ApiError.Validation("subject");
        UrlPolicyService.Text(r.Subject.IdNumber,"subject.idNumber",32);
        if(!r.Subject.IdNumber.All(char.IsAsciiDigit)) throw ApiError.Validation("subject.idNumber");
        if(r.AuthenticationType==AuthenticationType.OTP && string.IsNullOrWhiteSpace(r.Subject.MobileNumber))
            throw ApiError.Validation("subject.mobileNumber");
        if(r.Subject.MobileNumber is not null && (r.Subject.MobileNumber.Length is < 7 or > 20
            || !r.Subject.MobileNumber.TrimStart('+').All(char.IsAsciiDigit))) throw ApiError.Validation("subject.mobileNumber");
        if(r.MaxAccessCount is <= 0) throw ApiError.Validation("maxAccessCount");
        if(r.Locale is not ("en" or "ar")) throw ApiError.Validation("locale");
        if(r.ExpiresAt is { } expiry && (expiry.Offset!=TimeSpan.Zero || expiry<=rules.Now)) throw ApiError.Validation("expiresAt","INVALID_EXPIRY");
        var purpose=rules.Purpose(r.PurposeCode);
        var auth=purpose.AuthPolicies.FirstOrDefault(id=>settings.Authentication.TryGetValue(id,out var a)&&a.Type==r.AuthenticationType)
            ?? throw ApiError.Validation("authenticationType","AUTH_POLICY_NOT_ALLOWED");
        if(r.AuthenticationType==AuthenticationType.NoAuth && !purpose.Anonymous) throw ApiError.Validation("authenticationType","AUTH_POLICY_NOT_ALLOWED");
        var (target,content)=Target(r.Mode.Value,r.Target);
        var request=new CreateUrlRequest(r.Mode,r.PurposeCode,r.BusinessReference,r.Subject.IdNumber,auth,r.ExpiresAt,
            r.Locale,target,content?.ContentType,content?.FileName,content?.Sha256,r.Subject,r.MaxAccessCount);
        var domain=await rules.Domain(request,owner,ct);
        if(purpose.ReceiptTenYears)
        {
            if(domain.IssuedAt is null) throw ApiError.Validation("expiresAt","INVALID_EXPIRY");
            var expiryAt=domain.IssuedAt.Value.AddYears(10);
            if(request.ExpiresAt is not null && request.ExpiresAt!=expiryAt) throw ApiError.Validation("expiresAt","INVALID_EXPIRY");
            request=request with{ExpiresAt=expiryAt};
        }
        else if(request.ExpiresAt is null && purpose.DefaultExpirySeconds is { } duration)
            request=request with{ExpiresAt=rules.Now.AddSeconds(duration)};
        if(purpose.MaximumExpirySeconds is { } max && request.ExpiresAt>rules.Now.AddSeconds(max)) throw ApiError.Validation("expiresAt","INVALID_EXPIRY");
        return request;
    }
    public (Target?,InlineContent?) Target(UrlMode mode, ReviewedTarget? value)
    {
        if(mode==UrlMode.Draft)
        {
            // Optional staged content is validated but remains inaccessible while Draft.
            return value is null ? (null,null) : Target(value.Content is null?UrlMode.RewriteUrl:UrlMode.Content,value);
        }
        if(value is null) throw ApiError.Validation("target");
        if(value.BaseProfileId is not null && value.BackendProfileId is not null && value.BaseProfileId!=value.BackendProfileId)
            throw ApiError.Validation("target.baseProfileId","PROFILE_CONFLICT");
        if(mode==UrlMode.Content)
        {
            if(value.Content is null || value.Url is not null || value.BaseProfileId is not null || value.BackendProfileId is not null)
                throw ApiError.Validation("target","INVALID_TARGET");
            return (null,value.Content);
        }
        if(value.Content is not null || string.IsNullOrWhiteSpace(value.Url)) throw ApiError.Validation("target","INVALID_TARGET");
        var profile=value.BaseProfileId??value.BackendProfileId??settings.DefaultTargetProfileId;
        var target=new Target(BackendProfileId:profile,Url:value.Url);
        targets.Validate(mode,target);return (target,null);
    }
    public async Task StoreContent(IRepositoryContext tx,UrlRecord r,InlineContent? content,CancellationToken ct)
    {
        if(content is null) {r.ContentId=null;r.Content=null;return;}
        if(content.Base64 is null || content.Base64.Length>settings.MaxFileBytes*4L/3+4) throw ApiError.Validation("target.content.base64","INVALID_CONTENT");
        byte[] bytes;
        try {bytes=Convert.FromBase64String(content.Base64);} catch(FormatException){throw ApiError.Validation("target.content.base64","INVALID_CONTENT");}
        var hash=FileRules.Validate(bytes,content.ContentType,content.FileName,content.Sha256,settings.MaxFileBytes);
        await integrations.Scan(bytes,hash,ct);r.ContentId=Guid.NewGuid().ToString("N");r.Content=new(content.ContentType,bytes.Length,hash);
        tx.Content.Save(r.ContentId,bytes);
    }
}
