namespace ALJUF.Paperless;
public sealed record ReviewedUrlResource(string UrlId, string PublicUrl, UrlKind Kind, UrlMode Mode, UrlStatus Status,
    string PurposeCode, BusinessReference BusinessReference, AuthenticationType AuthenticationType,
    DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt, DateTimeOffset? ExpiresAt, long Version,
    string? ParentUrlId = null);
