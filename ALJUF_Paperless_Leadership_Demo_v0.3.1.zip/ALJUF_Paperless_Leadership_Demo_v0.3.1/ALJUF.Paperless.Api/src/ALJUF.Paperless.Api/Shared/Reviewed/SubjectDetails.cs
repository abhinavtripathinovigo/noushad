namespace ALJUF.Paperless;
public sealed record SubjectDetails(string IdNumber, string? MobileNumber = null);
