namespace ALJUF.Paperless;

public interface IAccessSessionRepository
{
    SessionRecord? Get(string id);
    List<SessionRecord> FindByProviderHash(string hash);
    void Save(SessionRecord record);
}
