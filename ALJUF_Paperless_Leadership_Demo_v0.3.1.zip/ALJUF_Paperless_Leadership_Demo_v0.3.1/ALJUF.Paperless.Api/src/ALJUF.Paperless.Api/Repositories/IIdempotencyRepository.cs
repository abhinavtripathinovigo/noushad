namespace ALJUF.Paperless;

public interface IIdempotencyRepository
{
    StoredIdempotency? Get(string id);
    void Save(string id, StoredIdempotency record);
}
