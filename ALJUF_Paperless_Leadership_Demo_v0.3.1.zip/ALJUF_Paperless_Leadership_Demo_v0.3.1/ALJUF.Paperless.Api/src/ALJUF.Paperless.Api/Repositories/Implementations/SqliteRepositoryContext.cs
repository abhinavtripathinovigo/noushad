namespace ALJUF.Paperless;

internal sealed class SqliteRepositoryContext(SqliteUnitOfWork.Transaction tx) : IRepositoryContext
{
    public IUrlRepository Urls { get; } = new SqliteUrlRepository(tx);
    public IAccessSessionRepository Sessions { get; } = new SqliteAccessSessionRepository(tx);
    public IContentRepository Content { get; } = new SqliteContentRepository(tx);
    public IIdempotencyRepository Idempotency { get; } = new SqliteIdempotencyRepository(tx);
    public IAuditRepository Audit { get; } = new SqliteAuditRepository(tx);
}
