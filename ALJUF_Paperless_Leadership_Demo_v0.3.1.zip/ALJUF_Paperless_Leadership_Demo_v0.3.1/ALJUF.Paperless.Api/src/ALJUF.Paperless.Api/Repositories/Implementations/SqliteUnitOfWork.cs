using Microsoft.AspNetCore.DataProtection;
using Microsoft.Data.Sqlite;

namespace ALJUF.Paperless;

// Durable single-node reference store. Do not mount this SQLite file across OKE replicas.
// Protected record payloads include public tokens, sessions, replies and content bytes.
public sealed class SqliteUnitOfWork : IUnitOfWork
{
    private readonly string connectionString;
    private readonly IDataProtector protector;
    public SqliteUnitOfWork(Settings settings, IDataProtectionProvider protection)
    {
        Directory.CreateDirectory(settings.DataDirectory);
        connectionString = new SqliteConnectionStringBuilder
        {
            DataSource = Path.Combine(settings.DataDirectory, "paperless.db"), DefaultTimeout = 15
        }.ToString();
        protector = protection.CreateProtector("ALJUF.Paperless.Store.v1");
        using var connection = Open();
        using var command = connection.CreateCommand();
        command.CommandText = """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS Records (
                Kind TEXT NOT NULL, Id TEXT NOT NULL, Lookup TEXT NOT NULL,
                Payload BLOB NOT NULL, PRIMARY KEY (Kind, Id));
            CREATE INDEX IF NOT EXISTS IX_Records_Lookup ON Records(Kind, Lookup);
            """;
        command.ExecuteNonQuery();
    }
    private SqliteConnection Open()
    {
        var c = new SqliteConnection(connectionString); c.Open();
        using var cmd = c.CreateCommand(); cmd.CommandText = "PRAGMA synchronous=FULL; PRAGMA busy_timeout=15000;"; cmd.ExecuteNonQuery();
        return c;
    }
    public async Task<T> Write<T>(Func<IRepositoryContext, Task<T>> action)
    {
        await using var connection = Open();
        using var tx = connection.BeginTransaction(deferred: false);
        var result = await action(new SqliteRepositoryContext(new Transaction(connection, tx, protector)));
        tx.Commit();
        return result;
    }
    public T Read<T>(Func<IRepositoryContext, T> action)
    {
        using var c = Open(); return action(new SqliteRepositoryContext(new Transaction(c, null, protector)));
    }
    internal sealed class Transaction(SqliteConnection connection, SqliteTransaction? transaction, IDataProtector protector)
    {
        private SqliteCommand Command(string sql, params (string, object)[] parameters)
        {
            var cmd = connection.CreateCommand(); cmd.Transaction = transaction; cmd.CommandText = sql;
            foreach (var (name, value) in parameters) cmd.Parameters.AddWithValue(name, value);
            return cmd;
        }
        public T? Get<T>(string kind, string id) where T : class
        {
            using var c = Command("SELECT Payload FROM Records WHERE Kind=$k AND Id=$id", ("$k", kind), ("$id", id));
            return c.ExecuteScalar() is byte[] bytes ? Json.Decode<T>(protector.Unprotect(System.Text.Encoding.UTF8.GetString(bytes))) : null;
        }
        public List<T> Find<T>(string kind, string lookup) where T : class
        {
            using var c = Command("SELECT Payload FROM Records WHERE Kind=$k AND Lookup=$l", ("$k", kind), ("$l", lookup));
            using var r = c.ExecuteReader(); var list = new List<T>();
            while (r.Read()) list.Add(Json.Decode<T>(protector.Unprotect(System.Text.Encoding.UTF8.GetString((byte[])r[0]))));
            return list;
        }
        public void Put<T>(string kind, string id, T value, string lookup = "")
        {
            var bytes = System.Text.Encoding.UTF8.GetBytes(protector.Protect(Json.Encode(value)));
            using var c = Command("INSERT INTO Records VALUES($k,$id,$l,$p) ON CONFLICT(Kind,Id) DO UPDATE SET Lookup=$l,Payload=$p",
                ("$k", kind), ("$id", id), ("$l", lookup), ("$p", bytes));
            c.ExecuteNonQuery();
        }
        public void Audit(string action, string id, string actor, DateTimeOffset now)
            => Put("audit", Guid.NewGuid().ToString("N"), new { action, resourceId = id, actor, occurredAt = now });
    }
}
