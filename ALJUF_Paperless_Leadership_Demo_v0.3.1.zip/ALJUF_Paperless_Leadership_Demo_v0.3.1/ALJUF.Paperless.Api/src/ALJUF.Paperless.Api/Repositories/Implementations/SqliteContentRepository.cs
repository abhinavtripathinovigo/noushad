namespace ALJUF.Paperless;

internal sealed class SqliteContentRepository(SqliteUnitOfWork.Transaction tx) : IContentRepository
{
    public byte[]? Get(string id) => tx.Get<byte[]>("content", id);
    public void Save(string id, byte[] bytes) => tx.Put("content", id, bytes);
}
