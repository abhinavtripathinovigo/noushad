namespace ALJUF.Paperless;

internal sealed class SqliteIdempotencyRepository(SqliteUnitOfWork.Transaction tx) : IIdempotencyRepository
{
    public StoredIdempotency? Get(string id) => tx.Get<StoredIdempotency>("idempotency", id);
    public void Save(string id, StoredIdempotency record) => tx.Put("idempotency", id, record);
}
