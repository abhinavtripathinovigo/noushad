namespace ALJUF.Paperless;

public interface IContentRepository
{
    byte[]? Get(string id);
    void Save(string id, byte[] bytes);
}
