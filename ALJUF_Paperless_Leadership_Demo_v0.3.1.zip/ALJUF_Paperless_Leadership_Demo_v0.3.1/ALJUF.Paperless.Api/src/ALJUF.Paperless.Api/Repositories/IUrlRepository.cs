namespace ALJUF.Paperless;

public interface IUrlRepository
{
    UrlRecord? Get(string id);
    List<UrlRecord> FindByTokenHash(string hash);
    List<UrlRecord> FindByBinding(string binding);
    void Save(UrlRecord record);
}
