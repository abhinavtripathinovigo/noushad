namespace ALJUF.Paperless;

public interface IUnitOfWork
{
    Task<T> Write<T>(Func<IRepositoryContext, Task<T>> action);
    T Read<T>(Func<IRepositoryContext, T> action);
}
