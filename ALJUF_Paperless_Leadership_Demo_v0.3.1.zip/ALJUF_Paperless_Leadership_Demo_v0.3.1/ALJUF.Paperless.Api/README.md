# ALJUF Paperless URL API — v0.3.1

## ALJUF leadership demo — 8 November 2026

This version refreshes the presentation of `/demo`, the completion screen and customer verification screen. It adds a responsive navy-and-gold layout, a three-step journey, selected-file details, accessible keyboard focus and processing feedback. The QR cover heading now reads ALJUF. The ALJUF wordmark is rendered as text; no official logo artwork is bundled.

Open this solution in Visual Studio, select **Paperless Browser Demo**, and press F5. The browser opens `/demo`. Select an unsigned synthetic PDF, create the QR-stamped copy, open the customer page and enter `0123` when prompted. The link lasts five minutes and works on this computer. The original document is retained after the added cover page.

The demo still uses its existing local document workflow. The reviewed `/v2` APIs and interface workbook v0.5 are unchanged. No interface-specification revision is required for this visual update.

The build and affected integration test passed. Automated browser launch was blocked in the authoring environment, so desktop/mobile visual review must be completed on the presentation computer before the leadership session. See `docs/VALIDATION.md` for the executed checks and limitations.

## Reviewed JSON contracts — interface workbook v0.5

This version adds independent controllers, request/response classes and feature services for the reviewed `/v2` contracts. Existing `/v1` endpoints remain available. The shared persistence and authorization infrastructure remains common to these features; this is one deployable reference application, not independently deployed microservices.

Use `POST /v2/urls`, optionally `PATCH /v2/urls`, then `POST /v2/temp-urls` and `POST /v2/qr-codes`. Store the regular `urlId` returned by CreateURL. Temporary creation accepts that ID and returns a **new temporary ID** to pass to GenerateQR. Its response contains exactly `urlId`, `publicUrl`, `kind`, `createdAt`, `updatedAt`, `expiresAt` and `version`. The public route is `/t/{token}`. The parent relation is retained internally and available through the companion metadata endpoint `GET /v2/urls/{id}`.

The management ID and unguessable public token are separate values. Sample IDs and timestamps are illustrative. Normalized JSON samples under `samples/reviewed-v2` use synthetic identity data and a synthetic PDF. Replace example IDs with actual response IDs and use current expiry values when testing.

### Visual Studio and Swagger

Open `ALJUF.Paperless.sln`, set the API project as startup project, select **Paperless Browser Demo**, and press F5. Browse to `https://localhost:7243/swagger`. No additional Swagger package is required. The `/demo` PDF uploader remains the legacy demonstration; use the reviewed operations in Swagger to exercise `/v2`.

For Swagger management requests, configure a private development key of at least 32 characters under `Paperless:DevelopmentApiKey` in `src/ALJUF.Paperless.Api/appsettings.Development.json` (or Visual Studio Manage User Secrets), restart, and use Swagger **Authorize** with the `X-Development-Api-Key` scheme. Do not commit your key. Supply a fresh `Idempotency-Key` for each mutation; retry the same request with the same key. Update requires the returned strong ETag in `If-Match`, for example `"v1"`. Without a configured key the browser-demo profile generates an internal key; it is not exposed to Swagger.

### Changes and review decisions

- Temporary duration uses server UTC time plus `expireAfterMinutes`. Omission uses the configurable default of 5 minutes. A child cannot outlive its parent; its expiry is capped at parent expiry. Replaying creation does not extend expiry.
- `baseProfileId` and `backendProfileId` are accepted aliases. Conflicting simultaneous values are rejected. Profiles, allowed destinations and credentials are configured on the server.
- `sizePx` means pixels and defaults to 50. PNG requires at least two pixels per QR module including its quiet zone; insufficient size returns `QR_SIZE_TOO_SMALL` with the required minimum. Use a larger value such as 300 for a practical local test. SVG permits vector scaling; verify actual printed size and scan quality. Icon IDs require registered assets; no corporate icon was fabricated.
- Draft links remain inactive. They may stage a target and allow the owner to create a regular QR before PDF assembly. Activation requires a concrete mode and valid target. Target/revision changes require a complete replacement target and document revision.
- Parent updates invalidate existing child bindings. Deactivation blocks child access. Access and authentication-attempt limits are shared with the parent. Access is counted when document delivery or redirect authorization is committed, including a subsequent client disconnect; it is not a count of confirmed human views.
- Parent-expiry capping, version invalidation, aggregate counters, configured bounds and Draft assembly are explicit implementation choices recorded for approval in the workbook, not additional BRD claims.
- Identity fields are kept in protected storage and omitted from resource responses. Provider adapter requests now carry subject identity where needed; agree these adapter contracts with downstream owners before deployment.

Development configuration uses a separate `data-reviewed-v03` directory. `QUOTATION` allows NoAuth and the synthetic IDVerify4Digit fixture for local testing only. The synthetic ID is `0000000123` and its four-digit evidence is `0123`. The `api-gateway-ecm` destination is a nonfunctional `.invalid` placeholder; real backend, identity provider, scanner and icon configuration is still required. This delivery does not implement the seven additional proposed production APIs or the complete five-service architecture.

The sections below describe retained legacy capabilities and deployment prerequisites. Their `/v1` request examples are not the reviewed `/v2` payload format.

## Visual Studio browser demo

The **Paperless Browser Demo** profile also serves Swagger UI at **/swagger** and OpenAPI 3.0 JSON at **/swagger/v1/swagger.json**. That document includes both `/v1` and reviewed `/v2` routes; its URL is retained for compatibility. Click **View the API in Swagger** on the demo page. For a quick check expand **Health**, choose **Try it out**, then **Execute**. Management calls require the correct development credentials; browser verification uses the cookies and CSRF token issued by the customer page. Swagger UI 5.34.1 and its license notices are included under ApiDocumentation and served locally in Development only. No separate package installation is necessary.

Open `ALJUF.Paperless.sln`, set `ALJUF.Paperless.Api` as the startup project, select the **Paperless Browser Demo** launch profile and press **F5**. Open `https://localhost:7243/demo` if the browser does not open automatically. Choose an unsigned synthetic PDF, select **Create QR-stamped PDF**, then **Open customer page**. The first page of the downloaded PDF contains the QR code for that customer link. Original pages follow. A localhost URL works on the computer running the demo, not on a separate phone. Enter **0123** when prompted. The link lasts five minutes.

This profile runs locally over HTTPS in Development. It calculates the digest and expiry for you and generates an in-memory development key if none is configured. It does not send a management key to the browser. Existing script and production configuration instructions below still apply when using those modes.

ASP.NET Core 10 implementation of the **Paperless URL API Interface Specifications v0.1 (26 October 2026)**. All `(x)` items are included. This is a runnable reference implementation for engineering review and integration, not a completed production deployment.

## Implemented

- CreateUrl: RedirectUrl, RewriteUrl, Content and BaseUrl.
- Update target, replace content and activate/deactivate, with strong ETags.
- Temporary URLs with fixed expiry; activation and QR rendering cannot renew them.
- PNG/SVG QR generation for either URL kind, including a configured PNG icon.
- Public landing page, EN/AR language switch, CSRF protection, browser-bound authentication sessions and authorized document retrieval.
- Customer authentication policy types: NoAuth, OTP, AbsherOTP, Nafath, IDVerify and IDVerify4Digit.
- Backend profiles: NoAuth, BasicAuth and APIKey; credentials resolved from environment-injected secrets.
- Durable idempotency, attempt counters, audit records, session state, content and metadata; cancellation/revocation invalidates subsequent access.
- JWT bearer authentication and operation scopes for management and integration APIs.

**Integration boundary:** real OTP, Absher, Nafath, identity verification, business-validity checking, antivirus scanning and destination-grant exchange require approved provider adapters. Their normalized HTTP contracts are implemented in `HttpIntegrations`; they are not invented vendor-native endpoints. Missing providers fail closed. There is no “always successful” production identity verifier.

## Build and test

Install a .NET 10 SDK, then run from this directory:

```powershell
dotnet restore ALJUF.Paperless.sln --configfile NuGet.Config
dotnet build ALJUF.Paperless.sln -c Release --no-restore
dotnet test ALJUF.Paperless.sln -c Release --no-build
```

Dependencies are pinned in the project files. `global.json` accepts installed .NET 10 feature-band updates. See `docs/VALIDATION.md` for the checks actually performed on this delivery.

## Local demonstration

Use synthetic files only. Development fixtures bypass the antivirus adapter, recognize only `demo-customer`, and accept last-four evidence `0123` for that synthetic customer. OTP, AbsherOTP, Nafath and IDVerify remain unavailable in this mode.

```powershell
dotnet dev-certs https --trust
$env:ASPNETCORE_ENVIRONMENT = 'Development'
$env:Paperless__DevelopmentApiKey = '<choose-a-local-secret-at-least-32-characters-long>'
dotnet run --project src/ALJUF.Paperless.Api --urls https://localhost:7243
```

In a second PowerShell 7 terminal, set the same development key and run:

```powershell
$env:Paperless__DevelopmentApiKey = '<same-local-secret>'
./scripts/demo.ps1 -PdfPath ./your-synthetic-document.pdf
```

The script creates a protected temporary link and a QR PNG. Open the returned public URL and enter `0123`. Use a different synthetic document ID for a new business document, or reuse the same idempotency key when retrying an uncertain request. The script generates new IDs on each intentional run.

Development API authentication uses `X-Development-Api-Key` only when **both** `ASPNETCORE_ENVIRONMENT=Development` and `EnableDevelopmentFixtures=true`. Production rejects that combination at startup. Do not expose the development host publicly.

## Production configuration

Supply settings through your deployment secret/configuration mechanism. Do not commit secrets or certificates.

| Setting | Purpose |
|---|---|
| `Paperless__JwtAuthority`, `Paperless__JwtAudience` | Approved OAuth/OIDC issuer and audience. Tokens need `client_id` or `azp`, and space-separated `scope` claims. |
| `Paperless__PublicOrigin` | Real HTTPS public origin, with no path/query. |
| `AllowedHosts` | Approved hostnames for the application. |
| `Paperless__DataDirectory` | Persistent, access-controlled volume for this single-node reference store and its key ring. |
| `Paperless__KeyCertificatePath`, `Paperless__KeyCertificatePassword` | Certificate protecting persisted Data Protection keys; required outside Development/Testing. |
| `Paperless__AdapterBaseUrl`, `Paperless__AdapterApiKey` | HTTPS integration adapter base URL and secret. The base must end in `/`. |
| `Paperless:ClientPurposes:<client-id>` | Explicit list of purposes permitted to that authenticated consumer. Production mappings start empty. |
| `Paperless:Backends`, `BaseProfiles`, `RedirectOrigins` | Explicitly approved backend and redirect destinations. Empty by default. |
| `Paperless:Icons:ALJUF-logo-v1` | Local path to the approved PNG logo. No substitute corporate logo is supplied. |

Management scopes are `url:create`, `url:read`, `url:update`, `qr:generate`. Provider callbacks require `auth:callback` and a `provider` claim matching the path. Domain invalidation requires `url:lifecycle` and the owning `client_id`/`azp`.

Gateway-issued identity headers are **not** trusted as authentication. The service validates bearer tokens itself. Configure trusted proxy forwarding explicitly at deployment if needed; it is not enabled for arbitrary proxies. Disable token/body/query logging at Apigee, ingress, APM and downstream adapters as well as in the API.

## Storage and deployment boundary

The supplied implementation uses **SQLite with protected record payloads and bounded encrypted PDF content** to make the project self-contained and restart-safe. Writes use SQLite transactions and are serialized. This is suitable for local evaluation and a single-node integration environment; it is **not the final multi-replica OKE persistence design**. Do not mount the same SQLite database across pods.

For production, replace `SqliteUnitOfWork` and its repository implementations with your approved relational store, put content in private object storage/ECM, retain the atomic idempotency/version/attempt semantics, and share/protect the Data Protection key ring. Design the object-publication transaction/outbox, cleanup, retention/holds and backups before rollout. This delivery retains records and older content; it does not silently delete ten-year receipts or audit evidence.

The repository deliberately holds a write transaction across some adapter operations to preserve reference-implementation consistency. Replace this with durable operation reservations/outbox/reconciliation before high-volume or multi-node use. Configure budgets and load-test; no production capacity is claimed.

## Policy decisions still required

See `docs/SPEC_MAPPING.md` for the complete mapping and deviations. In particular:

- BaseUrl currently means a registered destination base plus a relative path, resolved as a guarded redirect.
- Quotation display expiry defaults to five minutes; the older-PDF QR exception is not implemented as an expiry bypass.
- Receipt expiry is ten calendar years from a trusted domain-issued timestamp. That timestamp is mandatory for this purpose.
- The five-attempt quotation rule is implemented. Other authentication policies currently have a **provisional five-attempt security limit**, not a claim that the receipt BRD approved that business rule. Obtain policy approval before enabling those journeys.
- Purpose configuration governs authentication, immutability, branding and lifetime. `DRIVE_AUTHORIZATION` uses Nafath as a provisional choice; confirm the required method.
- Default limits (5 MiB PDF, 180-second sessions, 24-hour idempotency retention, 120 requests/minute per partition, 8 concurrent requests, 10-second dependency deadline) are implementation defaults, not approved BRD service levels. Multipart buffering stays in memory within the bounded upload size, avoiding plaintext temporary file spills.
- The public page is a usable document-access sample. Its Arabic/English copy needs business/legal review. No document submission, survey or signature workflow is implied.

## Structure

The source uses controllers, feature service interfaces and typed repository interfaces. All existing routes and JSON contracts are retained. Each class/record/interface has a named source file.

```text
src/ALJUF.Paperless.Api/
  Features/
    CreateUrl/       CreateUrlController.cs, ICreateUrlService.cs, CreateUrlService.cs
    CreateTempUrl/   CreateTempUrlController.cs, ICreateTempUrlService.cs, CreateTempUrlService.cs
    UpdateUrl/       UpdateUrlController.cs, IUpdateUrlService.cs, UpdateUrlService.cs
    UrlMetadata/     UrlMetadataController.cs, IUrlMetadataService.cs, UrlMetadataService.cs
    GenerateQR/      GenerateQrController.cs, IGenerateQrService.cs, GenerateQrService.cs
    PublicAccess/    PublicAccessController.cs, IPublicAccessService.cs, PublicAccessService.cs
    Lifecycle/       LifecycleController.cs, ILifecycleService.cs, LifecycleService.cs
  Authentication/   AuthCallbackController.cs, DevelopmentHandler.cs, Contracts/
  Repositories/     IUnitOfWork.cs, IRepositoryContext.cs, typed repository interfaces
    Implementations/ SQLite unit of work and individual repository classes
    Entities/        Persisted URL, session and idempotency models
  Integrations/     Individual adapter interfaces, implementations and decision models
  Shared/           Common contracts, policies, creation workflow, validation and HTTP helpers
  Configuration/    Settings and dependency injection
  Program.cs        Register, build, configure pipeline, map controllers, run
tests/              Service and HTTP integration tests
```

See [CODE_STRUCTURE.md](docs/CODE_STRUCTURE.md) for controller-to-service mappings and the repository transaction design. These are independent code modules within one deployable application. Regular and temporary creation share validation; multiple features share repositories where they access the same data.

## Reference documentation

- [JWT bearer configuration](https://learn.microsoft.com/en-us/aspnet/core/security/authentication/configure-jwt-bearer-authentication?view=aspnetcore-10.0)
- [QRCoder](https://github.com/Shane32/QRCoder)
- [SkiaSharp](https://github.com/mono/SkiaSharp)

These describe implementation libraries. The supplied BRD and interface workbook remain the source of business requirements.
