using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using ALJUF.Paperless;
using Xunit;

namespace ALJUF.Paperless.Tests;

public sealed class ApiFactory : WebApplicationFactory<Program>
{
    public const string Key="development-test-key-never-use-in-production";
    private readonly Dictionary<string,string?> previous = new();
    public ApiFactory()
    {
        foreach(var pair in new Dictionary<string,string>
        {
            ["Paperless__DevelopmentApiKey"]=Key,
            ["Paperless__DataDirectory"]=Path.Combine(Path.GetTempPath(),"ALJUF-http-"+Guid.NewGuid().ToString("N")),
            ["Paperless__PublicOrigin"]="https://localhost"
        })
        {
            previous[pair.Key]=Environment.GetEnvironmentVariable(pair.Key);
            Environment.SetEnvironmentVariable(pair.Key,pair.Value);
        }
    }
    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.UseContentRoot(Path.GetFullPath(Path.Combine(AppContext.BaseDirectory,"../../../../../src/ALJUF.Paperless.Api")));
    }
    protected override void Dispose(bool disposing)
    {
        base.Dispose(disposing);
        if(disposing)foreach(var pair in previous)Environment.SetEnvironmentVariable(pair.Key,pair.Value);
    }
}
public sealed class HttpTests : IClassFixture<ApiFactory>
{
    private readonly ApiFactory factory;
    public HttpTests(ApiFactory factory)=>this.factory=factory;
    private HttpClient Client(bool authenticated=true)
    {
        var c=factory.CreateClient(new WebApplicationFactoryClientOptions{BaseAddress=new Uri("https://localhost"),AllowAutoRedirect=false});
        if(authenticated)c.DefaultRequestHeaders.Add("X-Development-Api-Key",ApiFactory.Key);
        return c;
    }
    [Fact] public async Task ReviewedJsonRoutesFollowParentChildSequence()
    {
        using var c=Client();
        using var create=new HttpRequestMessage(HttpMethod.Post,"/v2/urls"){Content=Body(new {mode="Draft",purposeCode="QUOTATION",
            businessReference=new {system="FS",entityType="Quotation",entityId="demo",documentId=Guid.NewGuid().ToString("N"),documentRevision="V1"},
            subject=new {idNumber="0000000123"}})};
        create.Headers.Add("Idempotency-Key",Guid.NewGuid().ToString("N"));
        var response=await c.SendAsync(create);Assert.Equal(HttpStatusCode.Created,response.StatusCode);
        var root=Json.Decode<ReviewedUrlResource>(await response.Content.ReadAsStringAsync());
        using var update=new HttpRequestMessage(HttpMethod.Patch,"/v2/urls"){Content=Body(new{urlId=root.UrlId,mode="Content",
            target=new{content=new{base64=Convert.ToBase64String(Harness.Pdf),contentType="application/pdf",fileName="demo.pdf",sha256=Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Harness.Pdf))}},
            documentRevision="V2",status="Active"})};
        update.Headers.Add("Idempotency-Key",Guid.NewGuid().ToString("N"));update.Headers.TryAddWithoutValidation("If-Match",response.Headers.ETag!.Tag);
        Assert.Equal(HttpStatusCode.OK,(await c.SendAsync(update)).StatusCode);
        using var temp=new HttpRequestMessage(HttpMethod.Post,"/v2/temp-urls"){Content=Body(new{urlId=root.UrlId,expireAfterMinutes=5})};
        temp.Headers.Add("Idempotency-Key",Guid.NewGuid().ToString("N"));
        var created=await c.SendAsync(temp);Assert.Equal(HttpStatusCode.Created,created.StatusCode);
        using var json=System.Text.Json.JsonDocument.Parse(await created.Content.ReadAsStringAsync());
        Assert.Equal(7,json.RootElement.EnumerateObject().Count());
        var child=Json.Decode<ReviewedTempUrlResource>(json.RootElement.GetRawText());
        Assert.Equal(TimeSpan.FromMinutes(5),child.ExpiresAt-child.CreatedAt);
        Assert.Equal(HttpStatusCode.OK,(await c.GetAsync(new Uri(child.PublicUrl).AbsolutePath)).StatusCode);
        var qr=await c.PostAsync("/v2/qr-codes",Body(new{urlId=child.UrlId,kind="Temporary",format="png",sizePx=300}));
        Assert.Equal(HttpStatusCode.OK,qr.StatusCode);Assert.Equal("image/png",qr.Content.Headers.ContentType!.MediaType);
    }
    private static StringContent Body(object value)=>new(Json.Encode(value),Encoding.UTF8,"application/json");
    [Fact] public async Task SwaggerServesUiAssetsAndActualApiContracts()
    {
        using var c=Client(false);
        var redirect=await c.GetAsync("/swagger");
        Assert.Equal("/swagger/index.html",redirect.Headers.Location?.ToString());
        Assert.Contains("swagger-ui-bundle.js",await c.GetStringAsync("/swagger/index.html"));
        foreach(var asset in new[]{"swagger-ui-bundle.js","swagger-ui.css","init.js"})
            Assert.Equal(HttpStatusCode.OK,(await c.GetAsync("/swagger/"+asset)).StatusCode);
        using var spec=System.Text.Json.JsonDocument.Parse(await c.GetStringAsync("/swagger/v1/swagger.json"));
        var paths=spec.RootElement.GetProperty("paths");
        Assert.Equal(21,paths.EnumerateObject().Sum(p=>p.Value.EnumerateObject().Count()));
        Assert.True(paths.GetProperty("/v1/temp-urls").GetProperty("post").GetProperty("requestBody")
            .GetProperty("content").TryGetProperty("multipart/form-data",out _));
    }
    [Fact] public async Task ManagementRejectsAnonymousCaller()
    {
        using var c=Client(false);var response=await c.GetAsync("/v1/urls/unknown");Assert.Equal(HttpStatusCode.Unauthorized,response.StatusCode);
    }
    [Fact] public async Task UnknownJsonFieldReturns400()
    {
        using var c=Client();c.DefaultRequestHeaders.Add("Idempotency-Key",Guid.NewGuid().ToString());
        var response=await c.PostAsync("/v1/urls",new StringContent("{\"surprise\":true}",Encoding.UTF8,"application/json"));Assert.Equal(HttpStatusCode.BadRequest,response.StatusCode);
    }
    [Fact] public async Task ContentPublicJourneyEnforcesCsrfAndReturnsExactBytes()
    {
        using var c=Client();var request=new CreateUrlRequest(UrlMode.Content,"DEMO_PUBLIC",new("LOS","DEMO","e",Guid.NewGuid().ToString(),"r1"),null,"demo-none",DateTimeOffset.UtcNow.AddMinutes(5),
            ContentType:"application/pdf",FileName:"demo.pdf",Sha256:Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(Harness.Pdf)));
        using var form=new MultipartFormDataContent();form.Add(Body(request),"metadata");form.Add(new ByteArrayContent(Harness.Pdf),"file","demo.pdf");
        using var create=new HttpRequestMessage(HttpMethod.Post,"/v1/urls"){Content=form};create.Headers.Add("Idempotency-Key",Guid.NewGuid().ToString());
        var response=await c.SendAsync(create);Assert.Equal(HttpStatusCode.Created,response.StatusCode);
        Assert.Equal("\"v1\"",response.Headers.ETag!.Tag);
        var resource=Json.Decode<UrlResource>(await response.Content.ReadAsStringAsync());
        var landing=await c.GetAsync(new Uri(resource.PublicUrl).PathAndQuery);Assert.Equal(HttpStatusCode.OK,landing.StatusCode);
        var html=await landing.Content.ReadAsStringAsync();
        var token=Regex.Match(html,"name=\"csrf-token\" content=\"([^\"]+)\"").Groups[1].Value;Assert.NotEmpty(token);
        var access=new AccessRequest(new Uri(resource.PublicUrl).Segments.Last());
        var denied=await c.PostAsync("/public/v1/access-sessions",Body(access));Assert.Equal(HttpStatusCode.Forbidden,denied.StatusCode);
        using var start=new HttpRequestMessage(HttpMethod.Post,"/public/v1/access-sessions"){Content=Body(access)};
        start.Headers.Add("Origin","https://localhost");start.Headers.Add("X-CSRF-TOKEN",WebUtility.HtmlDecode(token));start.Headers.Add("Idempotency-Key",Guid.NewGuid().ToString());
        var started=await c.SendAsync(start);Assert.Equal(HttpStatusCode.Created,started.StatusCode);
        var session=Json.Decode<AccessSession>(await started.Content.ReadAsStringAsync());Assert.Equal(SessionState.Authorized,session.State);
        var content=await c.GetAsync($"/public/v1/access-sessions/{session.SessionId}/resource");Assert.Equal(HttpStatusCode.OK,content.StatusCode);
        Assert.Equal(Harness.Pdf,await content.Content.ReadAsByteArrayAsync());
        Assert.Contains("no-store",content.Headers.CacheControl!.ToString());
    }
    [Fact] public async Task CallbackCannotBeInvokedWithManagementIdentity()
    {
        using var c=Client();var response=await c.PostAsync("/internal/v1/auth-callbacks/nafath",Body(new CallbackRequest("e","p","Approved",DateTimeOffset.UtcNow)));
        Assert.Equal(HttpStatusCode.Forbidden,response.StatusCode);
    }

    [Fact] public async Task ManagementControllersPreserveTemporaryUrlLifecycle()
    {
        using var client = Client();
        async Task<HttpResponseMessage> Send(HttpMethod method, string path, object body, string? etag = null)
        {
            using var message = new HttpRequestMessage(method, path) { Content = Body(body) };
            message.Headers.Add("Idempotency-Key", Guid.NewGuid().ToString());
            if (etag is not null) message.Headers.Add("If-Match", etag);
            return await client.SendAsync(message);
        }

        var expiry = DateTimeOffset.UtcNow.AddMinutes(5);
        var request = new CreateUrlRequest(UrlMode.RedirectUrl, "DEMO_PUBLIC",
            new("LOS", "DEMO", "entity", Guid.NewGuid().ToString(), "r1"), null, "demo-none", expiry,
            Target: new(RedirectUrl: "https://documents.example.invalid/document"));
        using var created = await Send(HttpMethod.Post, "/v1/temp-urls", request);
        Assert.Equal(HttpStatusCode.Created, created.StatusCode);
        var resource = Json.Decode<UrlResource>(await created.Content.ReadAsStringAsync());
        Assert.Equal(UrlKind.Temporary, resource.Kind);
        Assert.Equal(expiry, resource.ExpiresAt);
        var path = "/v1/urls/" + resource.UrlId;
        using var metadata = await client.GetAsync(path);
        Assert.Equal(HttpStatusCode.OK, metadata.StatusCode);
        Assert.Equal("\"v1\"", metadata.Headers.ETag!.Tag);

        using var target = await Send(HttpMethod.Patch, path + "/target",
            new TargetUpdate(new(RedirectUrl: "https://documents.example.invalid/revised"), "r2"), "\"v1\"");
        Assert.Equal(HttpStatusCode.OK, target.StatusCode);
        Assert.Equal("\"v2\"", target.Headers.ETag!.Tag);
        using var inactive = await Send(HttpMethod.Patch, path + "/status", new StatusUpdate(UrlStatus.Inactive, "TEST"), "\"v2\"");
        Assert.Equal(HttpStatusCode.OK, inactive.StatusCode);
        using var active = await Send(HttpMethod.Patch, path + "/status", new StatusUpdate(UrlStatus.Active, "TEST"), "\"v3\"");
        Assert.Equal(HttpStatusCode.OK, active.StatusCode);
        using var qr = await Send(HttpMethod.Post, "/v1/qr-codes", new QrRequest(resource.UrlId));
        Assert.Equal(HttpStatusCode.OK, qr.StatusCode);
        Assert.Equal("image/png", qr.Content.Headers.ContentType!.MediaType);
        Assert.True((await qr.Content.ReadAsByteArrayAsync()).AsSpan().StartsWith(new byte[] { 137, 80, 78, 71 }));

        using var revoked = await Send(HttpMethod.Post, "/internal/v1/lifecycle-events",
            new LifecycleRequest(Guid.NewGuid().ToString(), resource.UrlId, "Cancelled", 1));
        Assert.Equal(HttpStatusCode.NoContent, revoked.StatusCode);
        using var final = await client.GetAsync(path);
        Assert.Equal(UrlStatus.Revoked, Json.Decode<UrlResource>(await final.Content.ReadAsStringAsync()).Status);
        using var landing = await client.GetAsync(new Uri(resource.PublicUrl).PathAndQuery);
        Assert.Equal(HttpStatusCode.NotFound, landing.StatusCode);
    }
}
