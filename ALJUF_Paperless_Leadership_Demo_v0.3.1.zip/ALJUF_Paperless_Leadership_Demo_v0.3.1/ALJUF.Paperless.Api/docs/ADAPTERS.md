# Integration adapter contract

The API calls a **ALJUF-owned adapter facade**. These are proposed internal contracts. Do not send them directly to Absher, Nafath, Newgen or another vendor without mapping to that vendor's actual interface.

All calls are POST to the configured HTTPS `AdapterBaseUrl` (include a trailing slash), with `X-Adapter-Key` from a secret. JSON is camelCase; enum values are strings. Errors, timeouts, malformed/unknown fields or absent configuration do not authorize access. No request/response body logging is permitted.

## `domain/validate`

Request: `{ "callerId": "registered-client", "request": <CreateUrlRequest> }`

Response:

```json
{"valid":true,"documentRevision":"r1","issuedAt":null}
```

The adapter must validate the caller's entitlement to the business purpose, customer/document association, final issuance state, current revision and target/content ownership. Check cancellation/rejection/expiry against the authoritative LOS/LMS/FS/SRM record. `issuedAt` is the authoritative receipt issue time when applicable, in UTC. Never simply echo a request revision and set `valid=true`.

This check is made at creation, relevant updates and public access. The supplied reference adapter is synchronous; a production event/cache design must bound staleness and reconcile missed events.

## `content/scan`

Request: `{ "contentBase64": "...", "sha256": "..." }`

Response: `{ "clean": true }`

Only return true after the agreed PDF validation/malware checks complete. Scanner unavailability is not clean content. This small-file synchronous interface should be replaced by a staged-object/scanning workflow if approved payload sizes or scan latency exceed its limits.

## `authentication/start`

Request fields: `urlId`, `subjectRef`, `method`, `provider`, `idempotencyKey`.

Response example:

```json
{"state":"ChallengeRequired","providerRequestId":"provider-owned-request-reference"}
```

For asynchronous verification return `Pending`. The adapter resolves the trusted mobile/identity record; the browser cannot select a replacement destination. Non-NoAuth start responses cannot directly authorize a customer. Provider requests must be unique and bound to customer, URL and method.

## `authentication/verify`

Request fields: `urlId`, `subjectRef`, `method`, `provider`, `providerRequestId`, `evidence`, `idempotencyKey`.

Evidence has exactly one of `otpCode`, `identityNumber`, `idLast4`, as permitted by the bound method. Response: `{ "state":"Authorized","providerRequestId":null }` or `Denied`. A provider error must remain an error; never interpret missing/empty results as approval. Verification and challenge creation must deduplicate the supplied key even if the URL API retries after a timeout/crash.

## Asynchronous callback

The adapter authenticates the vendor callback first, verifies signature/freshness/request/customer correspondence, then sends the normalized message to:

`POST /internal/v1/auth-callbacks/{provider}`

```json
{"eventId":"unique-provider-event","providerRequestId":"stored-request-reference","result":"Approved","occurredAt":"2026-10-26T10:01:00Z"}
```

The adapter bearer token must have `scope=auth:callback` and `provider` equal to the path. Allowed result values: Approved, Denied, Expired. The API accepts only a matching pending, unexpired, current-version session. Duplicate event IDs are idempotent; late approval cannot revive a session. The current replay-age window is ten minutes with one minute future tolerance, pending provider SLA approval.

## `destinations/grant`

Request: `{ "urlId":"...", "subjectRef":"...", "target":"https://approved-host/path", "expiresAt":"2026-10-26T10:03:00Z" }`

Response: `{ "location":"https://approved-host/path?grant=<scoped-value>" }`

The adapter must create a short-lived, document/customer-scoped destination authorization grant or session. The destination must enforce it independently. The API permits an approved query change, but not a change of host/path. Grant expiry must not exceed the permitted link/session validity; implement the final grant exchange with the destination owner. No Basic password, API key or permanent public document URL may be returned as a substitute.

## Backend profile examples

These examples are inactive configuration templates. The hosts and authentication intent were provided by the user; protocol, routes and header names have not been verified.

```json
{
  "Paperless": {
    "Backends": {
      "ecm-document-read": {
        "baseUri":"https://newgenecm.aljfs.com/",
        "pathPrefix":"/documents/",
        "authType":"BasicAuth",
        "usernameEnvironmentVariable":"ALJUF_ECM_USERNAME",
        "secretEnvironmentVariable":"ALJUF_ECM_PASSWORD"
      },
      "apig-document-read": {
        "baseUri":"https://iapiweb.aljfs.com/",
        "pathPrefix":"/documents/",
        "authType":"APIKey",
        "apiKeyHeader":"X-Api-Key",
        "secretEnvironmentVariable":"ALJUF_APIG_API_KEY"
      }
    }
  }
}
```

If Newgen uses login/session tokens rather than HTTP Basic, implement that adapter before enabling the profile. Do not translate a username/password requirement into Basic authentication without confirmation.
