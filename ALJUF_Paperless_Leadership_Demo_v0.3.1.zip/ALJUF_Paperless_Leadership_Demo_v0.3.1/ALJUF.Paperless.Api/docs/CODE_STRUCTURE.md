# Controller, service and repository structure — v0.2

This solution is one deployable ASP.NET Core application. Each API capability has a named controller, a service interface, an implementation and its request models. Separate source files do not create separately deployable microservices.

## Find an API

All paths below are relative to `src/ALJUF.Paperless.Api/`.

| Capability | Folder | Controller → interface → implementation |
|---|---|---|
| CreateUrl, all four modes | `Features/CreateUrl/` | `CreateUrlController` → `ICreateUrlService` → `CreateUrlService` |
| Fixed-expiry temporary URL | `Features/CreateTempUrl/` | `CreateTempUrlController` → `ICreateTempUrlService` → `CreateTempUrlService` |
| Update target/content/status | `Features/UpdateUrl/` | `UpdateUrlController` → `IUpdateUrlService` → `UpdateUrlService` |
| Read URL metadata | `Features/UrlMetadata/` | `UrlMetadataController` → `IUrlMetadataService` → `UrlMetadataService` |
| QR generation, including icon | `Features/GenerateQR/` | `GenerateQrController` → `IGenerateQrService` → `GenerateQrService` |
| Public landing, sessions, verification and retrieval | `Features/PublicAccess/` | `PublicAccessController` → `IPublicAccessService` → `PublicAccessService` |
| Authentication callbacks | `Authentication/` | `AuthCallbackController` → `IPublicAccessService.Callback` |
| Lifecycle invalidation | `Features/Lifecycle/` | `LifecycleController` → `ILifecycleService` → `LifecycleService` |

Each name in the last column has its own `.cs` file. Feature request records are in the corresponding `Contracts/` subfolder; shared wire models are in `Shared/Contracts/`. Temporary URL creation intentionally reuses `CreateUrlRequest`: its wire fields match regular creation, but its service requires fixed expiry. Redirect, Rewrite, Content and Base are modes of the existing CreateUrl endpoint; their routes have not been invented or split.

## How a request travels

```text
HTTP POST /v1/urls
  CreateUrlController             HTTP parsing, authenticated identity, response
    ICreateUrlService
      CreateUrlService            selects regular URL creation
        UrlCreationWorkflow       validation, expiry, domain check, content scan
          UrlPolicyService        authorization, validity, binding, idempotency
            IUnitOfWork.Write
              IRepositoryContext
                IUrlRepository / IContentRepository
                IIdempotencyRepository / IAuditRepository
                  SQLite implementations, one shared transaction
```

UpdateUrlService owns target, content and status update logic. PublicAccessService owns customer session state and verification; GenerateQrService owns QR rendering. No feature delegates back to a combined legacy UrlService.

## Shared infrastructure and intentional reuse

- `Shared/Services/UrlCreationWorkflow.cs`: common regular/temporary creation algorithm. The two creation services choose the required lifetime behavior without copying security or publication rules.
- `Shared/Services/UrlPolicyService.cs`: shared ownership, domain validity, policy, version, binding and idempotency rules used by multiple features.
- `Repositories/IUnitOfWork.cs` and `IRepositoryContext.cs`: atomic work across typed repositories. Repositories are created within each unit of work, not injected as singletons with live connections.
- `Repositories/IUrlRepository.cs`, `IAccessSessionRepository.cs`, `IContentRepository.cs`, `IIdempotencyRepository.cs`, `IAuditRepository.cs`: persistence contracts. Corresponding `Sqlite...Repository.cs` classes live in `Implementations/`; entities live in `Entities/`.
- `Integrations/`: separate files for the adapter interface, HTTP implementation, development fixtures, decision contracts and approved backend target resolution.
- `Configuration/DependencyInjection.cs`: registers every feature interface and implementation, repository unit of work, authentication and limits.
- `Shared/Http/`: error pipeline, request parsing, response handling, controller base and health endpoint.
- `Program.cs`: application composition only: register, build, configure pipeline, map controllers, run.

The URL, its business binding, content metadata, idempotent reply and audit record must commit together. They therefore share repositories by data responsibility rather than creating a duplicate repository for each HTTP operation. URL/session/payload schema and Data Protection purpose remain unchanged from v0.1; this is not a database migration.

## Deployment boundary

The SQLite implementation remains a single-node reference adapter. Replacing it requires implementing `IUnitOfWork` and the repository interfaces with the approved production persistence design and retaining transaction/idempotency guarantees. External provider integration, distributed operation recovery and multi-replica OKE readiness remain separate delivery work described in README and SPEC_MAPPING.
