# Interface specification mapping

Source: `ALJUF_Paperless_URL_API_Interface_Specifications_v0.1.xlsx`, 26 October 2026. All paths below implement proposed v0.1 contracts; they are not assertions about legacy FS routes.

| ID | Method and path | Implementation |
|---|---|---|
| CU01–CU04 | POST `/v1/urls` | JSON target variants, multipart Content variant; `CreateUrlController` → `ICreateUrlService` → `CreateUrlService` |
| TU01 | POST `/v1/temp-urls` | Same variants, mandatory fixed `expiresAt` |
| UU01 | PATCH `/v1/urls/{id}/target` | Type-preserving target replacement with If-Match |
| UU02 | PUT `/v1/urls/{id}/content` | Validated, scanned, atomic replacement; immutable purposes denied |
| UU03 | PATCH `/v1/urls/{id}/status` | Active/Inactive only; expired/revoked resources cannot be revived |
| MD01 | GET `/v1/urls/{id}` | Owner-authorized metadata and ETag |
| QR01 | POST `/v1/qr-codes` | PNG/SVG and registered icon; exact existing URL; no renewal |
| PA01 | GET `/u/{token}` | Access page and CSRF bootstrap; no OTP initiation on GET |
| PA02 | POST `/public/v1/access-sessions` | Purpose-selected authentication and browser-bound flow cookie |
| PA03 | POST `/public/v1/access-sessions/{id}/verify` | OTP/identity evidence, atomic attempt counter, authorized cookie |
| PA04 | GET `/public/v1/access-sessions/{id}` | Session status and delivery/recovery of authorization cookie after callback |
| PA05 | GET `/public/v1/access-sessions/{id}/resource` | Checked private content, backend fetch or guarded redirect |
| PA06 | POST `/internal/v1/auth-callbacks/{provider}` | JWT provider identity, callback deduplication, request correlation and expiry checks |
| R09 support | POST `/internal/v1/lifecycle-events` | Proposed normalized invalidation endpoint; caller ownership, event idempotency and sequence guard |

The full controller, service and repository map is in [CODE_STRUCTURE.md](CODE_STRUCTURE.md). v0.2 changes source organization and HTTP routing implementation; it retains these v0.1 wire contracts.

## Authentication coverage

| Method | Working service behavior | External dependency |
|---|---|---|
| NoAuth | Immediate authorization only for explicitly anonymous purpose | Domain validity still checked |
| IDVerify4Digit | Exact four ASCII digits, leading zeros preserved, durable attempt counter | Trusted subject lookup/verification adapter; synthetic development fixture available |
| OTP / AbsherOTP | Challenge start, evidence validation, verification result handling | Approved provider adapter |
| Nafath | Pending flow and authenticated callback handling | Approved provider adapter; native challenge display/number matching still needs the vendor contract |
| IDVerify | Evidence transport and result handling | Exact identity assurance/verification meaning must be agreed |
| Backend NoAuth | No credential header | Explicitly configured allowed backend |
| Backend BasicAuth | Username/password from environment-secret references | Confirm ECM actually supports HTTP Basic |
| Backend APIKey | Header from configured environment-secret reference | Confirm apig header name and endpoint |

## Explicit implementation choices and gaps

1. **Single-node storage:** SQLite payloads and file bytes are Data Protection protected. This is a reference persistence adapter, not the final object-store/relational topology. Retention deletion, legal holds, multi-node coordination, outbox and disaster recovery are not delivered as deployed infrastructure.
2. **Idempotency:** create/update/authentication/lifecycle mutations persist their response in the same transaction as local state. QR rendering is deterministic and does not change URL validity; the supplied renderer does not maintain a separate binary response cache. Provider adapters must honor the supplied idempotency key, because a database rollback cannot undo an already-sent OTP.
3. **Purpose approval:** system scopes are supplemented by `ClientPurposes`. Production client mappings are empty by default. Domain validation must also check caller/customer/document entitlement, target ownership, issuance state and authoritative revision; client-supplied references are not evidence of entitlement.
4. **BaseUrl:** registered destination base + relative path, delivered as a guarded redirect. Alternate interpretations require revising `TargetResolver`.
5. **Fixed expiry:** server time is authoritative. Default quotation display TTL is 300 seconds. Earlier PDF-link exceptions remain unresolved and do not bypass expiry.
6. **Receipt:** trusted receipt issue time is required and `AddYears(10)` derives expiry. The business issuance workflow must prevent QR regeneration/reissue. Re-rendering an identical QR never changes its token or expiry. Retention deletion is not automatic. Non-quotation attempt limits remain provisional.
7. **Signed/issued documents:** configured immutable purposes reject generic target/content updates. New quotation revisions should create a new resource and revoke the old link through the domain workflow.
8. **Provider display and polling:** pending sessions receive authenticated callbacks; the API exposes status polling. Provider-specific matching numbers, resend, fallback and richer challenge UI are not guessed. An adapter rejection never falls back to NoAuth.
9. **Backend access:** only GET of approved PDF routes. No arbitrary method/header forwarding, redirects, HTML proxying or user-supplied credentials. Explicit host configuration must be paired with controlled DNS and OKE/network egress; application validation alone is not a network security boundary.
10. **Public UX:** simple EN/AR access page; API error messages are currently English with stable codes. Approved bilingual error/SMS templates, accessibility review and native identity-provider instructions remain delivery work.
11. **Submission:** customer uploads, form/survey submission, e-signature and SMS APIs are outside the supplied URL contract. Multipart Content publishes a system-provided PDF; it is not a customer submission endpoint.
12. **Limits and policy values:** the defaults listed in README are provisional. Authority URLs, real backends, client mappings, approved logo and adapter credentials are intentionally not populated.

Before a production baseline, resolve workbook decisions D01–D16, configure the approved integrations and storage adapters, and execute provider, load, recovery and deployment verification. No deployment has been performed by creating this project.
