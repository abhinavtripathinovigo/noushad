# Backend configuration — v0.6.0

For the Visual Studio **Paperless Browser Demo** profile, edit:

`src/ALJUF.Paperless.Api/appsettings.Development.json`

ASP.NET Core loads this after appsettings.json, so the Development values override the base file. For a non-Development deployment use the corresponding environment settings or injected secrets. All URLs in the delivery are placeholders and must be replaced. Restart after changing settings or rotating a certificate.

## FS: mutual TLS client certificate

Under `Paperless.Backends.FS`:

```json
{
  "BackendType": "FS",
  "BaseUri": "https://your-FS-host",
  "PathPrefix": "/approved-document-path/",
  "AuthType": "ClientCertificate",
  "ClientCertificateBase64": "BASE64_OF_PFX_OR_P12_BYTES",
  "ClientCertificatePasswordBase64": "BASE64_OF_UTF8_PASSWORD",
  "CertificateEnvironmentVariable": null,
  "CertificatePasswordEnvironmentVariable": null
}
```

The certificate must include its private key and be valid for client authentication. The password is the PFX/P12 import password, not a customer password. An unencrypted PFX uses an empty string for the encoded password. Invalid Base64, wrong password, missing private key, expired/not-yet-valid certificate or incompatible key usage fails explicitly. The client certificate is presented during the HTTPS handshake. Basic authentication and API-key/NoAuth fallback are rejected for FS.

Server certificate/hostname validation remains enabled. TLS revocation checking is enabled; the deployment must be able to validate the server trust chain. Client handlers are isolated by backend profile, redirects are disabled, and credentials are not forwarded to another host. Client keys are loaded using the service account's user key store without a persistent-key/exportable flag; that account must have the necessary key-store permissions on Windows. Test the real certificate and trust setup in your deployment.

Select FS in CreateURL/UpdateURL using a target such as:

```json
{
  "url": "/approved-document-path/document.pdf?id=example",
  "baseProfileId": "FS"
}
```

This is the `target` object, not a complete request. Use `mode: RewriteUrl` when Paperless must fetch the backend PDF with its server-side credentials. RedirectUrl/BaseUrl redirect behavior does not present Paperless's client certificate from the customer's browser.

## API gateway: API key

Under `Paperless.Backends.api-gateway-ecm`, set `BaseUri`, approved `PathPrefix`, `ApiKey` and `ApiKeyHeader`. `BackendType` is `ApiGateway`; `AuthType` is `APIKey`. Supported header names are `X-Api-Key` and `ApiKey`; confirm the gateway's actual header name. This is the outbound gateway credential, separate from the development management key used in Swagger. A missing key fails; NoAuth and BasicAuth are not accepted for this backend type.

The existing profile ID `api-gateway-ecm` is retained to keep reviewed request samples compatible; it now represents the API gateway option, not a direct ECM login.

## ECM wrapper: username/password followed by a session token

Under `Paperless.Backends.ecm-wrapper`, configure:

| Setting | Meaning |
|---|---|
| BaseUri / PathPrefix | Wrapper HTTPS origin and approved document path prefix. |
| AuthType | SessionToken. |
| WrapperContract | Set GetPdf only after confirming GET returns PDF bytes. Shipped as Unconfigured. |
| LoginPath | Root-relative login path on the same wrapper origin. |
| UsernameField / PasswordField | Exact JSON field names accepted by the login endpoint. |
| Username / Password | Wrapper login credentials, or use their environment-variable alternatives. |
| TokenJsonPath | Dot-separated path to the token string in the login JSON response; case-sensitive. |
| TokenHeaderName | Exact header required on the document request. |
| TokenPrefix | Required prefix, including any space; for example Bearer plus a space only if required by the wrapper. |

Implemented adapter sequence: POST JSON credentials to the configured login endpoint → extract the configured JSON token string → GET the selected wrapper document URL with that token header → require application/pdf. A new login is performed for each document retrieval; there is no shared token cache or invented session lifetime. Login failure, missing token or missing configuration never bypasses authentication.

The actual wrapper contract has not been supplied. Field names, URLs and token headers are deliberately blank, and document retrieval remains Unconfigured. If the wrapper requires form login, POST document retrieval, a session cookie or a JSON document-URL response, its adapter must be adjusted to that contract before enabling it. The code does not guess these formats or call ECM directly.

## Secrets

Base64 is encoding, not encryption. Do not commit completed credential values. Visual Studio User Secrets can hold these same configuration keys, or set environment-variable names in the profile. If an environment-variable name is configured it takes precedence, and a missing variable fails rather than falling back silently. Certificate environment variables contain Base64 values; the API-key and ECM username/password variables contain their actual string values. No real certificates or credentials are included in this delivery.

Customer `authenticationType` (NoAuth, IDVerify4Digit, OTP, etc.) is independent of backend credentials. Existing customer verification, URL expiry and access controls still apply before backend document retrieval.
