# Verification — backend options v0.6.0

Date: 9 November 2026. Release build and full .NET test suite succeeded: **50 passed, zero failed**.

New checks cover synthetic PFX import with a UTF-8/Base64 password, private-key presence, attachment to the correct HttpClient handler, handler isolation, no redirect following, normal server-certificate validation, rejection of FS BasicAuth/NoAuth/APIKey, wrong password, malformed Base64, invalid UTF-8, public-certificate-only input, expiry and incompatible EKU.

Gateway checks cover missing credentials, configured API-key header, named backend-client selection and origin restrictions. ECM tests simulate JSON username/password login followed by a nested session-token response, token-header document retrieval, failed login and missing token. Missing configuration fails; no NoAuth fallback is used.

The existing reviewed API, four-step demonstration, authentication, URL lifecycle, storage and QR regression tests remain included. Legacy management routes remain absent.

Limitations: synthetic certificates and simulated HTTP responses were used. No live FS TLS handshake, real API-gateway request or actual ECM wrapper was tested. ECM login field names, token path/header and document retrieval format still require the actual wrapper contract; only POST JSON login plus GET PDF retrieval is currently implemented. The shipped wrapper remains Unconfigured until that format is confirmed. Real-browser visual testing remains pending from the previous delivery.

The package includes blank credential slots only. No real certificate, password, gateway key, local database, generated binaries or protection keys are shipped.
