# Source structure

- `Features/CreateUrl`: reviewed controller, service and JSON contract.
- `Features/UpdateUrl`: reviewed controller, service and JSON contract.
- `Features/CreateTempUrl`: reviewed controller, service, request and seven-field response.
- `Features/GenerateQR`: reviewed controller, renderer and JSON contract; no legacy renderer branch.
- `Features/UrlMetadata`: reviewed metadata controller.
- `Features/PublicAccess`: session creation, verification, status and protected document retrieval.
- `Features/Lifecycle`: authenticated invalidation events.
- `Features/BrowserDemo`: four-step local demonstration using the reviewed services.
- `Features/Documentation`: locally served Swagger.
- `Shared/Reviewed`: reviewed HTTP shapes and normalization rules.
- `Shared/Domain`: normalized internal document data; not directly accepted from HTTP callers.
- `Repositories`: interfaces, entities and SQLite implementations shared by the features.
- `Integrations`: outbound provider adapters and destination validation.
- `Authentication`, `Configuration`, `Shared/Http`: request authentication, settings, DI and request handling.

Dependency flow: reviewed controller → reviewed feature service → common policy/domain helpers → repository interfaces. Browser authentication and provider lifecycle flows operate on the same stored resources.
