# Removed legacy files

The following files from v0.4.0 are not included in this clean source delivery.

- `Features/CreateUrl/CreateUrlController.cs`
- `Features/CreateUrl/CreateUrlService.cs`
- `Features/CreateUrl/ICreateUrlService.cs`
- `Features/CreateUrl/Contracts/CreateUrlRequest.cs`
- `Features/CreateTempUrl/CreateTempUrlController.cs`
- `Features/CreateTempUrl/CreateTempUrlService.cs`
- `Features/CreateTempUrl/ICreateTempUrlService.cs`
- `Features/UpdateUrl/UpdateUrlController.cs`
- `Features/UpdateUrl/UpdateUrlService.cs`
- `Features/UpdateUrl/IUpdateUrlService.cs`
- `Features/UpdateUrl/Contracts/ContentUpdate.cs`
- `Features/UpdateUrl/Contracts/StatusUpdate.cs`
- `Features/UpdateUrl/Contracts/TargetUpdate.cs`
- `Features/GenerateQR/GenerateQrController.cs`
- `Features/GenerateQR/GenerateQrService.cs`
- `Features/GenerateQR/IGenerateQrService.cs`
- `Features/GenerateQR/Contracts/QrRequest.cs`
- `Features/UrlMetadata/UrlMetadataController.cs`
- `Features/UrlMetadata/UrlMetadataService.cs`
- `Features/UrlMetadata/IUrlMetadataService.cs`
- `Shared/Services/UrlCreationWorkflow.cs`
- `Shared/Contracts/UrlResource.cs`
- `Shared/Contracts/Target.cs`

`DocumentDefinition` and `DocumentTarget` are normalized internal domain objects, not HTTP request contracts. Only reviewed request contracts are exposed for management operations.
