namespace ALJUF.Paperless;

public sealed class BackendProfile
{
    public string BackendType { get; set; } = "Unconfigured";
    public string BaseUri { get; set; } = "";
    public string PathPrefix { get; set; } = "/documents/";
    public string AuthType { get; set; } = "Unconfigured";
    public string ApiKeyHeader { get; set; } = "X-Api-Key";
    public string? ApiKey { get; set; }
    public string? SecretEnvironmentVariable { get; set; }
    public string? ClientCertificateBase64 { get; set; }
    public string? ClientCertificatePasswordBase64 { get; set; }
    public string? CertificateEnvironmentVariable { get; set; }
    public string? CertificatePasswordEnvironmentVariable { get; set; }
    public string WrapperContract { get; set; } = "Unconfigured";
    public string LoginPath { get; set; } = "";
    public string UsernameField { get; set; } = "";
    public string PasswordField { get; set; } = "";
    public string? Username { get; set; }
    public string? Password { get; set; }
    public string? UsernameEnvironmentVariable { get; set; }
    public string? PasswordEnvironmentVariable { get; set; }
    public string TokenJsonPath { get; set; } = "";
    public string TokenHeaderName { get; set; } = "";
    public string TokenPrefix { get; set; } = "";
}
