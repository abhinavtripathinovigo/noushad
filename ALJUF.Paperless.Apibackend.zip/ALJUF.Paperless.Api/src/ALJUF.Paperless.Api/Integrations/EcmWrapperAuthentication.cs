using System.Text;
using System.Text.Json;

namespace ALJUF.Paperless;

public static class EcmWrapperAuthentication
{
    private static ApiError Invalid() => new(503,"ECM_WRAPPER_CONFIGURATION_INVALID","Configure the ECM wrapper login and session-token contract.");
    public static async Task Authenticate(HttpClient client,BackendProfile profile,HttpRequestMessage document,CancellationToken ct)
    {
        BackendAuthentication.Validate(profile);
        if(profile.BackendType!="EcmWrapper" || profile.AuthType!="SessionToken")throw Invalid();
        var path=profile.LoginPath;
        if(string.IsNullOrWhiteSpace(path)||!path.StartsWith('/')||path.StartsWith("//")||path.Contains('\\')||path.Contains('?')||path.Contains('#')||path.Any(char.IsControl))throw Invalid();
        var decoded=Uri.UnescapeDataString(path);
        if(decoded.Contains('%')||decoded.Contains('\\')||decoded.Any(char.IsControl)||decoded.Split('/').Any(s=>s is "." or ".."))throw Invalid();
        if(string.IsNullOrWhiteSpace(profile.UsernameField)||string.IsNullOrWhiteSpace(profile.PasswordField)||profile.UsernameField==profile.PasswordField
            ||string.IsNullOrWhiteSpace(profile.TokenJsonPath)||profile.TokenJsonPath.Split('.').Any(string.IsNullOrWhiteSpace))throw Invalid();
        var header=profile.TokenHeaderName;
        if(string.IsNullOrWhiteSpace(header)||!header.All(c=>char.IsAsciiLetterOrDigit(c)||c=='-')
            ||new[]{"host","cookie","set-cookie","content-length","connection","transfer-encoding","proxy-authorization"}.Contains(header.ToLowerInvariant())
            ||header.StartsWith("Content-",StringComparison.OrdinalIgnoreCase)||profile.TokenPrefix.Any(char.IsControl))throw Invalid();
        string Secret(string? env,string? configured)
        {
            var value=string.IsNullOrWhiteSpace(env)?configured:Environment.GetEnvironmentVariable(env);
            return !string.IsNullOrWhiteSpace(value)?value:throw Invalid();
        }
        var username=Secret(profile.UsernameEnvironmentVariable,profile.Username);
        var password=Secret(profile.PasswordEnvironmentVariable,profile.Password);
        var loginUri=new Uri(new Uri(profile.BaseUri),path);
        if(loginUri.GetLeftPart(UriPartial.Authority)!=new Uri(profile.BaseUri).GetLeftPart(UriPartial.Authority))throw Invalid();
        using var login=new HttpRequestMessage(HttpMethod.Post,loginUri)
        {
            Content=new StringContent(JsonSerializer.Serialize(new Dictionary<string,string>{{profile.UsernameField,username},{profile.PasswordField,password}}),Encoding.UTF8,"application/json")
        };
        using var response=await client.SendAsync(login,HttpCompletionOption.ResponseHeadersRead,ct);
        if(!response.IsSuccessStatusCode)throw new ApiError(502,"BACKEND_AUTHENTICATION_FAILED","ECM wrapper login failed.");
        await using var stream=await response.Content.ReadAsStreamAsync(ct);
        var bytes=await FileRules.ReadBounded(stream,65536,ct);
        string token;
        try
        {
            using var json=JsonDocument.Parse(bytes);var value=json.RootElement;
            foreach(var segment in profile.TokenJsonPath.Split('.'))
            {
                if(value.ValueKind!=JsonValueKind.Object || !value.TryGetProperty(segment,out var next))throw Invalid();
                value=next;
            }
            if(value.ValueKind!=JsonValueKind.String)throw Invalid();
            token=value.GetString()!;
            if(string.IsNullOrWhiteSpace(token)||token.Length>8192||token.Any(char.IsControl))throw Invalid();
        }
        catch(JsonException){throw new ApiError(502,"BACKEND_AUTHENTICATION_FAILED","ECM wrapper returned an invalid login response.");}
        document.Headers.Add(header,profile.TokenPrefix+token);
        // Fresh login per retrieval: no shared token cache or unconfirmed token-expiry assumptions.
    }
}
