using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public sealed class DevelopmentIntegrations : IIntegrations
{
    public Task<DomainDecision> ValidateDomain(DocumentDefinition request, string owner, CancellationToken ct)
    {
        bool valid = request.SubjectRef is null or "demo-customer" or "0000000123";
        return Task.FromResult(new DomainDecision(valid, request.BusinessReference.DocumentRevision));
    }
    public Task Scan(byte[] bytes, string digest, CancellationToken ct) => Task.CompletedTask;
    public Task<AuthenticationDecision> Start(UrlRecord url, AuthPolicy policy, string key, CancellationToken ct)
    {
        if (policy.Type != AuthenticationType.IDVerify4Digit) throw ApiError.Unavailable();
        return Task.FromResult(new AuthenticationDecision(SessionState.ChallengeRequired, "dev-" + key));
    }
    public Task<AuthenticationDecision> Verify(UrlRecord url, SessionRecord session, Evidence evidence, string key, CancellationToken ct)
    {
        if (session.Method != AuthenticationType.IDVerify4Digit) throw ApiError.Unavailable();
        bool match = url.Request.SubjectRef is "demo-customer" or "0000000123" && Json.Equal(evidence.IdLast4 ?? "", "0123");
        return Task.FromResult(new AuthenticationDecision(match ? SessionState.Authorized : SessionState.Denied));
    }
    public Task<RedirectDecision> Redirect(UrlRecord url, string target, DateTimeOffset expiresAt, CancellationToken ct) => throw ApiError.Unavailable();
}
