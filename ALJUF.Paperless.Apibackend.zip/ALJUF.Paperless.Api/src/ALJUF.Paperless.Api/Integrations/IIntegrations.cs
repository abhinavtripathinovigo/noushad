using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public interface IIntegrations
{
    Task<DomainDecision> ValidateDomain(DocumentDefinition request, string owner, CancellationToken ct);
    Task Scan(byte[] bytes, string digest, CancellationToken ct);
    Task<AuthenticationDecision> Start(UrlRecord url, AuthPolicy policy, string key, CancellationToken ct);
    Task<AuthenticationDecision> Verify(UrlRecord url, SessionRecord session, Evidence evidence, string key, CancellationToken ct);
    Task<RedirectDecision> Redirect(UrlRecord url, string target, DateTimeOffset expiresAt, CancellationToken ct);
}

// These normalized endpoints are our adapter boundary, NOT claimed vendor-native APIs.
// Implement/map them against approved domain, antivirus, identity and destination contracts.
