using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace ALJUF.Paperless;

public static class BackendAuthentication
{
    public static string ClientName(string profileId) => "paperless-backend:" + profileId;
    private static ApiError Configuration() => new(503, "BACKEND_CONFIGURATION_INVALID", "The selected backend requires valid configuration.");
    public static void Validate(BackendProfile profile)
    {
        if (!Uri.TryCreate(profile.BaseUri,UriKind.Absolute,out var uri) || uri.Scheme != "https"
            || uri.UserInfo.Length>0 || uri.Query.Length>0 || uri.Fragment.Length>0) throw Configuration();
        bool valid=profile.BackendType switch
        {
            "FS" => profile.AuthType=="ClientCertificate",
            "ApiGateway" => profile.AuthType=="APIKey",
            "EcmWrapper" => profile.WrapperContract=="GetPdf" && profile.AuthType=="SessionToken",
            _ => false
        };
        if(!valid)throw Configuration();
    }
    private static string Resolve(string? environmentName,string? configured)
    {
        var value=string.IsNullOrWhiteSpace(environmentName)?configured:Environment.GetEnvironmentVariable(environmentName);
        return value ?? throw Configuration();
    }
    public static X509Certificate2 LoadCertificate(BackendProfile profile)
    {
        Validate(profile);
        if(profile.AuthType!="ClientCertificate")throw Configuration();
        byte[]? pfx=null;byte[]? passwordBytes=null;X509Certificate2? certificate=null;
        try
        {
            var encoded=Resolve(profile.CertificateEnvironmentVariable,profile.ClientCertificateBase64);
            if(encoded.Length==0 || encoded.Length>4*1024*1024)throw Configuration();
            pfx=Convert.FromBase64String(encoded);
            var encodedPassword=Resolve(profile.CertificatePasswordEnvironmentVariable,profile.ClientCertificatePasswordBase64);
            if(encodedPassword.Length>65536)throw Configuration();
            passwordBytes=Convert.FromBase64String(encodedPassword);
            var password=new UTF8Encoding(false,true).GetString(passwordBytes);
            // UserKeySet supports Windows TLS providers. No PersistKeySet or Exportable flag is used.
            certificate=X509CertificateLoader.LoadPkcs12(pfx,password,X509KeyStorageFlags.UserKeySet);
            var now=DateTime.UtcNow;
            if(!certificate.HasPrivateKey || certificate.NotBefore.ToUniversalTime()>now || certificate.NotAfter.ToUniversalTime()<=now)
                throw Configuration();
            foreach(var extension in certificate.Extensions)
            {
                if(extension is X509EnhancedKeyUsageExtension eku && !eku.EnhancedKeyUsages.Cast<Oid>().Any(o=>o.Value=="1.3.6.1.5.5.7.3.2"))throw Configuration();
                if(extension is X509KeyUsageExtension usage && !usage.KeyUsages.HasFlag(X509KeyUsageFlags.DigitalSignature))throw Configuration();
            }
            var result=certificate;certificate=null;return result;
        }
        catch(Exception e) when(e is FormatException or CryptographicException or DecoderFallbackException or ApiError)
        {throw new ApiError(503,"CLIENT_CERTIFICATE_INVALID","A valid client PFX/P12 certificate, private key and password are required.");}
        finally
        {
            certificate?.Dispose();if(pfx is not null)CryptographicOperations.ZeroMemory(pfx);
            if(passwordBytes is not null)CryptographicOperations.ZeroMemory(passwordBytes);
        }
    }
    public static void ApplyHeaders(BackendProfile profile,HttpRequestMessage request)
    {
        Validate(profile);
        if(profile.AuthType!="APIKey")return;
        if(profile.ApiKeyHeader is not ("X-Api-Key" or "ApiKey"))throw Configuration();
        var key=Resolve(profile.SecretEnvironmentVariable,profile.ApiKey);
        if(string.IsNullOrWhiteSpace(key) || key.Any(char.IsControl))throw Configuration();
        request.Headers.Add(profile.ApiKeyHeader,key);
    }
    public static HttpMessageHandler CreateHandler(BackendProfile profile)
    {
        Validate(profile);
        return new BackendHandler(profile.AuthType=="ClientCertificate"?LoadCertificate(profile):null);
    }
    private sealed class BackendHandler : HttpClientHandler
    {
        private readonly X509Certificate2? certificate;
        public BackendHandler(X509Certificate2? value)
        {
            certificate=value;AllowAutoRedirect=false;UseCookies=false;MaxConnectionsPerServer=16;
            ClientCertificateOptions=ClientCertificateOption.Manual;CheckCertificateRevocationList=true;
            if(value is not null)ClientCertificates.Add(value);
            // Server certificate and hostname validation use the platform defaults.
        }
        protected override void Dispose(bool disposing)
        {
            try{base.Dispose(disposing);}finally{if(disposing)certificate?.Dispose();}
        }
    }
}
