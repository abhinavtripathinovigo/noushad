using System.Net.Http.Headers;
using System.Text;

namespace ALJUF.Paperless;

public sealed class TargetResolver(Settings settings, IHttpClientFactory factory)
{
    public Uri Validate(UrlMode mode, DocumentTarget? target)
    {
        if (target is null || string.IsNullOrWhiteSpace(target.Url)) throw ApiError.Validation("target");
        if(mode is not (UrlMode.RewriteUrl or UrlMode.RedirectUrl or UrlMode.BaseUrl)
            || target.BackendProfileId is null || !settings.Backends.TryGetValue(target.BackendProfileId,out var profile))
            throw ApiError.Validation("target.baseProfileId","INVALID_TARGET");
        var raw=target.Url!;
        if(raw.Length>2048 || raw.Any(char.IsControl) || raw.Contains('\\') || raw.Contains('#') || raw.StartsWith("//"))
            throw ApiError.Validation("target.url","INVALID_TARGET");
        var decoded=Uri.UnescapeDataString(raw);
        if(decoded.Any(char.IsControl) || decoded.Contains('\\') || decoded.Contains('%')
            || decoded.Split('?')[0].Split('/').Any(x=>x==".."||x==".")) throw ApiError.Validation("target.url","INVALID_TARGET");
        var origin=Secure(profile.BaseUri);
        Uri uri;
        if(raw.StartsWith('/'))uri=new Uri(origin,raw);
        else if(Uri.TryCreate(raw,UriKind.Absolute,out var absolute))uri=Secure(absolute.AbsoluteUri);
        else throw ApiError.Validation("target.url","INVALID_TARGET");
        if(uri.GetLeftPart(UriPartial.Authority)!=origin.GetLeftPart(UriPartial.Authority)
            || !profile.PathPrefix.StartsWith('/') || !profile.PathPrefix.EndsWith('/')
            || !Uri.UnescapeDataString(uri.AbsolutePath).StartsWith(profile.PathPrefix,StringComparison.Ordinal))
            throw ApiError.Validation("target.url","INVALID_TARGET");
        if(mode is UrlMode.RedirectUrl or UrlMode.BaseUrl)Redirect(uri.AbsoluteUri);
        return uri;
    }
    public Uri Redirect(string text)
    {
        var uri = Secure(text);
        if (!settings.RedirectOrigins.Any(o => Secure(o).GetLeftPart(UriPartial.Authority) == uri.GetLeftPart(UriPartial.Authority)))
            throw ApiError.Validation("target", "INVALID_TARGET");
        return uri;
    }
    private static Uri Secure(string text)
    {
        if (!Uri.TryCreate(text, UriKind.Absolute, out var u) || u.Scheme != "https" || u.UserInfo.Length > 0 || u.Fragment.Length > 0)
            throw ApiError.Validation("target", "INVALID_TARGET");
        return u;
    }
    public async Task<byte[]> Fetch(UrlRecord url, CancellationToken ct)
    {
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        deadline.CancelAfter(TimeSpan.FromSeconds(settings.DependencyTimeoutSeconds));
        var target = url.Request.Target!;
        var uri = Validate(UrlMode.RewriteUrl, target);
        var profile = settings.Backends[target.BackendProfileId!];
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        BackendAuthentication.ApplyHeaders(profile,request);
        try
        {
            var client = factory.CreateClient(BackendAuthentication.ClientName(target.BackendProfileId!));
            if(profile.BackendType=="EcmWrapper")await EcmWrapperAuthentication.Authenticate(client,profile,request,deadline.Token);
            using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, deadline.Token);
            if (!response.IsSuccessStatusCode || response.StatusCode != System.Net.HttpStatusCode.OK)
                throw new ApiError(502, "BACKEND_FAILURE", "The document could not be retrieved.");
            if (response.Content.Headers.ContentType?.MediaType != "application/pdf") throw ApiError.Validation("backend.contentType", "INVALID_CONTENT");
            await using var stream = await response.Content.ReadAsStreamAsync(deadline.Token);
            return await FileRules.ReadBounded(stream, settings.MaxFileBytes, deadline.Token);
        }
        catch (HttpRequestException) { throw ApiError.Unavailable(); }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { throw new ApiError(504, "DEPENDENCY_TIMEOUT", "The dependency timed out."); }
    }
}
