"use strict";
SwaggerUIBundle({url:"./reviewed/swagger.json", dom_id:"#swagger-ui", validatorUrl:null,
    persistAuthorization:false, queryConfigEnabled:false, deepLinking:true,
    presets:[SwaggerUIBundle.presets.apis], layout:"BaseLayout"});
