using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace ALJUF.Paperless;

public sealed class UrlRecord
{
    public string? ParentUrlId { get; set; }
    public long? ParentVersion { get; set; }
    public long AccessCount { get; set; }
    public string Id { get; set; } = "";
    public string Owner { get; set; } = "";
    public string PublicToken { get; set; } = "";
    public string Binding { get; set; } = "";
    public DocumentDefinition Request { get; set; } = null!;
    public UrlKind Kind { get; set; }
    public UrlStatus Status { get; set; } = UrlStatus.Active;
    public DateTimeOffset CreatedAt { get; set; }
    public DateTimeOffset UpdatedAt { get; set; }
    public DateTimeOffset? ExpiresAt { get; set; }
    public long Version { get; set; } = 1;
    public string? ContentId { get; set; }
    public ContentMetadata? Content { get; set; }
    public int FailedAttempts { get; set; }
    public long DomainSequence { get; set; }
    public AuthenticationType AuthenticationType { get; set; }
}
