namespace ALJUF.Paperless;

public static class LocalSwagger
{
    public static void MapLocalSwagger(this WebApplication app)
    {
        if (!app.Environment.IsDevelopment()) return;
        app.MapGet("/swagger", () => Results.Redirect("/swagger/index.html"));
        foreach (var (route, file, mime) in new[] {
            ("/swagger/index.html", "index.html", "text/html; charset=utf-8"),
            ("/swagger/reviewed/swagger.json", "swagger.json", "application/json"),
            ("/swagger/swagger-ui.css", "swagger-ui.css", "text/css"),
            ("/swagger/swagger-ui-bundle.js", "swagger-ui-bundle.js", "application/javascript"),
            ("/swagger/init.js", "init.js", "application/javascript")
        })
        {
            app.MapGet(route, () => Results.Stream(typeof(LocalSwagger).Assembly
                .GetManifestResourceStream("PaperlessSwagger." + file)
                ?? throw new InvalidOperationException("Missing embedded Swagger asset."), mime));
        }
    }
}
