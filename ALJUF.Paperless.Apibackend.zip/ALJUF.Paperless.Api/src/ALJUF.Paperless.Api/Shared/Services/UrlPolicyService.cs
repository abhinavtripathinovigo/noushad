namespace ALJUF.Paperless;

public sealed class UrlPolicyService(IUnitOfWork store, Settings settings, IIntegrations integrations, TimeProvider clock)
{
    public DateTimeOffset Now => clock.GetUtcNow();
    public PurposePolicy Purpose(string code) => settings.Purposes.TryGetValue(code ?? "", out var p) ? p : throw ApiError.Validation("purposeCode");
    public AuthPolicy Auth(string id) => settings.Authentication.TryGetValue(id ?? "", out var p) ? p : throw ApiError.Validation("authPolicyId");
    public UrlStatus Effective(UrlRecord r) => r.Status == UrlStatus.Revoked ? UrlStatus.Revoked : r.ExpiresAt <= Now ? UrlStatus.Expired : r.Status;
    public string PublicUrl(UrlRecord r) => settings.PublicOrigin.TrimEnd('/') + (r.ParentUrlId is null ? "/u/" : "/t/") + r.PublicToken;
    public static string ETag(UrlRecord r) => $"\"v{r.Version}\"";
    public UrlRecord Owned(IRepositoryContext tx, string id, string owner)
    {
        var r = tx.Urls.Get(id);
        return r is not null && r.Owner == owner ? r : throw ApiError.Missing();
    }
    public static void Text(string? text, string field, int max = 128)
    {
        if (string.IsNullOrWhiteSpace(text) || text.Length > max || text.Any(char.IsControl)) throw ApiError.Validation(field);
    }
    public static void Precondition(UrlRecord r, string? etag)
    {
        if (string.IsNullOrWhiteSpace(etag)) throw new ApiError(428, "PRECONDITION_REQUIRED", "If-Match is required.");
        if (etag != ETag(r)) throw new ApiError(412, "VERSION_CONFLICT", "Read the resource and review the latest version.");
    }
    public async Task<Reply> Mutation(string owner, string operation, string key, object request,
        Func<IRepositoryContext, Task<Reply>> change)
    {
        Text(key, "Idempotency-Key", 128);
        var id = Json.Hash(owner + "|" + operation + "|" + key);
        var fingerprint = Json.Hash(Json.Encode(request));
        return await store.Write(async tx =>
        {
            var previous = tx.Idempotency.Get(id);
            if (previous is not null && previous.ExpiresAt > Now)
            {
                if (!Json.Equal(fingerprint, previous.Fingerprint)) throw ApiError.Conflict("IDEMPOTENCY_CONFLICT");
                return previous.Reply;
            }
            var reply = await change(tx);
            tx.Idempotency.Save(id, new StoredIdempotency(fingerprint, Now.AddHours(settings.IdempotencyHours), reply));
            return reply;
        });
    }
    public async Task<DomainDecision> Domain(DocumentDefinition request, string owner, CancellationToken ct)
    {
        if (!settings.ClientPurposes.TryGetValue(owner, out var purposes) || !purposes.Contains(request.PurposeCode))
            throw new ApiError(403, "FORBIDDEN", "The caller is not permitted to use this document purpose.");
        var result = await integrations.ValidateDomain(request, owner, ct);
        if (!result.Valid || result.DocumentRevision != request.BusinessReference.DocumentRevision) throw ApiError.Conflict("INVALID_STATE");
        return result;
    }
    public async Task Gate(UrlRecord r, CancellationToken ct)
    {
        if (Effective(r) != UrlStatus.Active || r.Request.Mode==UrlMode.Draft) throw ApiError.Missing();
        var root=r.ParentUrlId is null?r:store.Read(tx=>tx.Urls.Get(r.ParentUrlId))??throw ApiError.Missing();
        if(root.Owner!=r.Owner || (r.ParentUrlId is not null && (Effective(root)!=UrlStatus.Active || root.Version!=r.ParentVersion)))
            throw ApiError.Missing();
        if(root.Request.MaxAccessCount is { } max && root.AccessCount>=max)throw ApiError.Missing();
        var auth = Auth(r.Request.AuthPolicyId);
        if (auth.Type != r.AuthenticationType) throw ApiError.Unavailable(); // Policy versions must not change assurance silently.
        if (!Purpose(r.Request.PurposeCode).AuthPolicies.Contains(r.Request.AuthPolicyId)) throw ApiError.Missing();
        await Domain(r.Request, r.Owner, ct);
    }
    public void Save(IRepositoryContext tx, UrlRecord resource)
    {
        if(resource.ParentUrlId is not null) {resource.Binding=Json.Hash("child:"+resource.ParentUrlId+":"+resource.Id);tx.Urls.Save(resource);return;}
        var request = resource.Request;
        var binding = Json.Hash(Json.Encode(new { owner = resource.Owner, request.PurposeCode, request.BusinessReference.System,
            request.BusinessReference.EntityType, request.BusinessReference.EntityId, request.BusinessReference.DocumentId,
            request.BusinessReference.DocumentRevision, kind = resource.Kind == UrlKind.Temporary ? "Temporary" : "Regular" }));
        if (resource.Binding != binding && tx.Urls.FindByBinding(binding).Any(other => other.Id != resource.Id
            && (resource.Kind == UrlKind.Regular || Effective(other) is UrlStatus.Active or UrlStatus.Inactive))) throw ApiError.Conflict("DUPLICATE_BINDING");
        resource.Binding = binding;
        tx.Urls.Save(resource);
    }
    public void Bump(IRepositoryContext tx, UrlRecord r, string action)
    {
        r.Version++; r.UpdatedAt = Now; Save(tx, r); tx.Audit.Append(action, r.Id, r.Owner, Now);
    }
}
