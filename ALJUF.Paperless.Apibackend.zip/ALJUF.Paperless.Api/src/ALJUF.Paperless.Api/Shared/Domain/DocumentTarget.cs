namespace ALJUF.Paperless;

// Internal normalized destination; HTTP input uses ReviewedTarget.
public sealed record DocumentTarget(string? BackendProfileId = null, string? Url = null);
