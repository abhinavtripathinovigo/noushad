using System.Net;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Options;
using ALJUF.Paperless;

public static class Bodies
{
    public static async Task<T> Read<T>(HttpContext c)
    {
        if (!c.Request.HasJsonContentType()) throw new ApiError(415, "UNSUPPORTED_MEDIA_TYPE", "Use application/json.");
        var bytes = await FileRules.ReadBounded(c.Request.Body, typeof(T) == typeof(ReviewedCreateUrlRequest) || typeof(T) == typeof(ReviewedUpdateUrlRequest) ? checked(c.RequestServices.GetRequiredService<Settings>().MaxFileBytes * 4 / 3 + 65536) : 32768, c.RequestAborted);
        return Json.Decode<T>(System.Text.Encoding.UTF8.GetString(bytes));
    }
}
