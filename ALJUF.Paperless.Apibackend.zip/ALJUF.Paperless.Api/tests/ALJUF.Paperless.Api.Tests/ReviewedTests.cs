using System.Security.Cryptography;
using ALJUF.Paperless;
using Xunit;
namespace ALJUF.Paperless.Tests;
public sealed class ReviewedTests
{
    private static (UrlPolicyService rules,ReviewedCreateUrlService create,ReviewedUpdateUrlService update,ReviewedTempUrlService temp,ReviewedGenerateQrService qr) Services(Harness h)
    {
        var integrations=new DevelopmentIntegrations();
        var rules=new UrlPolicyService(h.Store,h.Settings,integrations,h.Clock);
        var reviewed=new ReviewedUrlPolicy(h.Settings,rules,h.Targets,integrations);
        return (rules,new(rules,reviewed),new(rules,reviewed,h.Targets),new(h.Settings,rules,reviewed),new(h.Store,rules,h.Settings));
    }
    private static ReviewedCreateUrlRequest Input(UrlMode mode=UrlMode.Content,int? max=null)=>new(mode,"PUBLIC",
        new("FS","Quotation","demo-001",Guid.NewGuid().ToString("N"),"V1"),new("0000000123"),
        MaxAccessCount:max,Target:mode==UrlMode.Draft?null:Content());
    private static ReviewedTarget Content()=>new(Content:new(Convert.ToBase64String(Harness.Pdf),"application/pdf","demo.pdf",Convert.ToHexString(SHA256.HashData(Harness.Pdf))));
    private static ReviewedUrlResource Resource(Reply r)=>Json.Decode<ReviewedUrlResource>(r.Body.GetRawText());
    [Fact] public async Task DraftUpdateTemporaryQrAndParentInvalidation()
    {
        using var h=new Harness();var s=Services(h);
        var created=await s.create.Create("client","create",Input(UrlMode.Draft),default);var root=Resource(created);
        Assert.Equal(UrlStatus.Inactive,root.Status);
        await Assert.ThrowsAsync<ApiError>(()=>s.temp.Create("client","too-early",new(root.UrlId),default));
        var image=await s.qr.Generate("client",new(root.UrlId,UrlKind.Regular,SizePx:333),default);
        Assert.Equal("image/png",image.ContentType);
        var update=await s.update.Update("client","update",created.ETag,new(root.UrlId,UrlMode.Content,Content(),UrlStatus.Active,"V2"),default);
        Assert.Equal("V2",Resource(update).BusinessReference.DocumentRevision);
        Assert.Equal(root.PublicUrl,Resource(update).PublicUrl);
        var first=await s.temp.Create("client","temp",new(root.UrlId),default);var child=Resource(first);
        Assert.Equal(root.UrlId,h.Store.Read(tx=>tx.Urls.Get(child.UrlId))!.ParentUrlId);Assert.NotEqual(root.UrlId,child.UrlId);
        Assert.Contains("/t/",child.PublicUrl);
        Assert.False(first.Body.TryGetProperty("parentUrlId",out _));
        Assert.Equal(1,child.Version);Assert.Equal(child.CreatedAt,child.UpdatedAt);
        Assert.Equal(h.Clock.Current.AddMinutes(5),child.ExpiresAt);
        h.Clock.Current=h.Clock.Current.AddMinutes(1);
        Assert.Equal(child.ExpiresAt,Resource(await s.temp.Create("client","temp",new(root.UrlId),default)).ExpiresAt);
        var png=await s.qr.Generate("client",new(child.UrlId,UrlKind.Temporary,SizePx:300),default);
        using var bitmap=SkiaSharp.SKBitmap.Decode(png.Bytes);Assert.Equal(300,bitmap.Width);
        await Assert.ThrowsAsync<ApiError>(()=>s.qr.Generate("client",new(child.UrlId,UrlKind.Regular,SizePx:300),default));
        var small=await Assert.ThrowsAsync<ApiError>(()=>s.qr.Generate("client",new(child.UrlId,UrlKind.Temporary),default));
        Assert.Equal("QR_SIZE_TOO_SMALL",small.Code);
        Assert.Equal("image/svg+xml",(await s.qr.Generate("client",new(child.UrlId,UrlKind.Temporary,"svg"),default)).ContentType);
        await s.update.Update("client","suspend",update.ETag,new(root.UrlId,Status:UrlStatus.Inactive,ReasonCode:"MANUAL_SUSPEND"),default);
        await Assert.ThrowsAsync<ApiError>(()=>s.qr.Generate("client",new(child.UrlId,UrlKind.Temporary,SizePx:300),default));
    }
    [Fact] public async Task ConfiguredMinutesAndParentExpiryCap()
    {
        using var h=new Harness();var s=Services(h);h.Settings.TemporaryUrlDefaultMinutes=7;
        var root=Resource(await s.create.Create("client","create",Input() with{ExpiresAt=h.Clock.Current.AddMinutes(9)},default));
        Assert.Equal(h.Clock.Current.AddMinutes(7),Resource(await s.temp.Create("client","a",new(root.UrlId),default)).ExpiresAt);
        Assert.Equal(h.Clock.Current.AddMinutes(9),Resource(await s.temp.Create("client","b",new(root.UrlId,15),default)).ExpiresAt);
        await Assert.ThrowsAsync<ApiError>(()=>s.temp.Create("client","c",new(root.UrlId,0),default));
        await Assert.ThrowsAsync<ApiError>(()=>s.temp.Create("other","d",new(root.UrlId),default));
    }
    [Fact] public async Task SharedAccessLimitAcrossRootAndChildren()
    {
        using var h=new Harness();var s=Services(h);
        var root=Resource(await s.create.Create("client","create",Input(max:1),default));
        var child=Resource(await s.temp.Create("client","temp",new(root.UrlId),default));
        var start=await h.Access.Start(new(child.PublicUrl.Split('/').Last()),"start","binding",default);
        var session=Harness.Session(start);
        var flow=start.Cookies!.Single(c=>c.Name==PublicAccessService.FlowCookie(session.SessionId)).Value;
        var auth=start.Cookies!.Single(c=>c.Name==PublicAccessService.AuthCookie(session.SessionId)).Value;
        Assert.Equal(Harness.Pdf,(await h.Access.Download(session.SessionId,flow,auth,default)).Bytes);
        Assert.Equal(1,h.Store.Read(tx=>tx.Urls.Get(root.UrlId))!.AccessCount);
        await Assert.ThrowsAsync<ApiError>(()=>h.Access.Download(session.SessionId,flow,auth,default));
        await Assert.ThrowsAsync<ApiError>(()=>s.temp.Create("client","another",new(root.UrlId),default));
    }
    [Fact] public async Task ValidationOwnershipAndAliases()
    {
        using var h=new Harness();var s=Services(h);h.Settings.DefaultTargetProfileId="ecm";
        var req=Input(UrlMode.RewriteUrl) with{Target=new("/documents/quotation?quoteId=123",BaseProfileId:"ecm")};
        var result=await s.create.Create("client","one",req,default);
        Assert.Equal(result.Body.GetRawText(),(await s.create.Create("client","one",req,default)).Body.GetRawText());
        var root=Resource(result);
        await s.update.Update("client","alias",result.ETag,new(root.UrlId,UrlMode.RewriteUrl,new("/documents/next?quoteId=124",BackendProfileId:"ecm"),UrlStatus.Active,"V2"),default);
        await Assert.ThrowsAsync<ApiError>(()=>s.create.Create("client","bad",req with{Target=new("/documents/x","ecm","other")},default));
        await Assert.ThrowsAsync<ApiError>(()=>s.create.Create("client","escape",req with{Target=new("https://evil.invalid/documents/x")},default));
        await Assert.ThrowsAsync<ApiError>(()=>s.create.Create("client","traversal",req with{Target=new("/documents/%2e%2e/private")},default));
        await Assert.ThrowsAsync<ApiError>(()=>s.create.Create("client","base64",Input() with{Target=new(Content:new("!","application/pdf","x.pdf","a"))},default));
        await Assert.ThrowsAsync<ApiError>(()=>s.create.Create("client","otp",Input() with{AuthenticationType=AuthenticationType.OTP},default));
        await Assert.ThrowsAsync<ApiError>(()=>s.update.Update("other","owner","\"v2\"",new(root.UrlId,Status:UrlStatus.Inactive,ReasonCode:"TEST"),default));
    }
}
