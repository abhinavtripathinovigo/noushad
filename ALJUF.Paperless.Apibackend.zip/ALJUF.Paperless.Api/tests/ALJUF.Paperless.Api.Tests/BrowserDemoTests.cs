using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace ALJUF.Paperless.Tests;

public class BrowserDemoTests(ApiFactory factory) : IClassFixture<ApiFactory>
{
    [Fact] public async Task LocalBrowserCreatesProtectedLinkWithoutApiKey()
    {
        using var app = factory.WithWebHostBuilder(b => b.UseSetting("Paperless:BrowserDemo", "true"));
        using var client = new HttpClient(app.Server.CreateHandler(c => c.Connection.RemoteIpAddress = IPAddress.Loopback))
            { BaseAddress = new Uri("https://localhost") };
        var page = await client.GetAsync("/demo");
        page.EnsureSuccessStatusCode();
        var html = await page.Content.ReadAsStringAsync();
        Assert.DoesNotContain(ApiFactory.Key, html);
        var token = Regex.Match(html, "name=\"__RequestVerificationToken\" value=\"([^\"]+)\"").Groups[1].Value;
        Assert.NotEmpty(token);
        client.DefaultRequestHeaders.Add("Cookie",page.Headers.GetValues("Set-Cookie").First().Split(';')[0]);
        using var form = new MultipartFormDataContent();
        form.Add(new StringContent(token), "__RequestVerificationToken");
        form.Add(new StringContent(Regex.Match(html, "name=\"ticket\" value=\"([^\"]+)\"").Groups[1].Value), "ticket");
        form.Add(new ByteArrayContent(Encoding.ASCII.GetBytes("%PDF-1.4\n% synthetic fixture\n%%EOF")), "file", "sample.pdf");
        var result = await client.PostAsync("/demo", form);
        Assert.True(result.IsSuccessStatusCode,await result.Content.ReadAsStringAsync());
        var preview = await result.Content.ReadAsStringAsync();
        var link = Regex.Match(preview, "href=\"(/t/[0-9a-fA-F]{64})\"").Groups[1].Value;
        Assert.NotEmpty(link);
        var child=app.Services.GetRequiredService<IUnitOfWork>().Read(tx=>tx.Urls.FindByTokenHash(Json.Hash(link.Split('/').Last())).Single());
        Assert.Equal(UrlKind.Temporary,child.Kind);Assert.NotNull(child.ParentUrlId);
        var parent=app.Services.GetRequiredService<IUnitOfWork>().Read(tx=>tx.Urls.Get(child.ParentUrlId!))!;
        Assert.Equal(UrlKind.Regular,parent.Kind);Assert.Equal(UrlMode.Content,parent.Request.Mode);

        Assert.DoesNotContain("data-qr=", html);
        Assert.DoesNotContain("stamp.js", html);
        Assert.Contains("The document has not been stamped yet", preview);
        Assert.Contains(DemoQrPresentation.Png("https://localhost" + link), preview);
        var landing = await client.GetAsync(link);
        Assert.Equal(HttpStatusCode.OK, landing.StatusCode);
        var access = await landing.Content.ReadAsStringAsync();
        Assert.Contains("id=\"stamp-stage\" hidden", access);
        Assert.Contains("id=\"stamp-after-auth\" type=\"button\" disabled", access);
        Assert.Contains("data-qr=\""+DemoQrPresentation.Png("https://localhost"+link)+"\"",access);
        Assert.Contains("/demo-assets/auth-stamp.js",access);
        client.DefaultRequestHeaders.Add("Origin","https://localhost");
        client.DefaultRequestHeaders.Add("X-CSRF-TOKEN",WebUtility.HtmlDecode(Regex.Match(access,"name=\"csrf-token\" content=\"([^\"]+)\"").Groups[1].Value));
        var cookies = new Dictionary<string,string>();
        foreach(var cookie in client.DefaultRequestHeaders.GetValues("Cookie")) {
            var pair=cookie.Split('=',2); cookies[pair[0]]=pair[1];
        }
        void Remember(HttpResponseMessage response) {
            if(response.Headers.TryGetValues("Set-Cookie",out var values))foreach(var value in values) {
                var pair=value.Split(';')[0].Split('=',2);cookies[pair[0]]=pair[1];
            }
            client.DefaultRequestHeaders.Remove("Cookie");client.DefaultRequestHeaders.Add("Cookie",string.Join("; ",cookies.Select(x=>x.Key+"="+x.Value)));
        }
        async Task<HttpResponseMessage> Post(string path,object body) {
            using var request=new HttpRequestMessage(HttpMethod.Post,path){Content=System.Net.Http.Json.JsonContent.Create(body)};
            request.Headers.Add("Idempotency-Key",Guid.NewGuid().ToString("N"));
            var response=await client.SendAsync(request);Remember(response);return response;
        }
        Remember(landing);
        var start=await Post("/public/v1/access-sessions",new{token=link.Split('/').Last(),locale="en"});
        start.EnsureSuccessStatusCode();
        using var session=System.Text.Json.JsonDocument.Parse(await start.Content.ReadAsStringAsync());
        var sid=session.RootElement.GetProperty("sessionId").GetString();
        Assert.Equal("ChallengeRequired",session.RootElement.GetProperty("state").GetString());
        var resource="/public/v1/access-sessions/"+sid+"/resource";
        Assert.NotEqual(HttpStatusCode.OK,(await client.GetAsync(resource)).StatusCode);
        var verified=await Post("/public/v1/access-sessions/"+sid+"/verify",new{evidence=new{idLast4="0123"}});
        verified.EnsureSuccessStatusCode();
        using var authorized=System.Text.Json.JsonDocument.Parse(await verified.Content.ReadAsStringAsync());
        Assert.Equal("Authorized",authorized.RootElement.GetProperty("state").GetString());
        var downloaded=await client.GetAsync(resource);downloaded.EnsureSuccessStatusCode();
        Assert.Equal("%PDF-1.4\n% synthetic fixture\n%%EOF",await downloaded.Content.ReadAsStringAsync());
        client.DefaultRequestHeaders.Remove("X-CSRF-TOKEN");
        using var invalid = new MultipartFormDataContent();
        invalid.Add(new StringContent("invalid"), "__RequestVerificationToken");
        Assert.Equal(HttpStatusCode.Forbidden, (await client.PostAsync("/demo", invalid)).StatusCode);
        using var remote = new HttpClient(app.Server.CreateHandler(c => c.Connection.RemoteIpAddress = IPAddress.Parse("192.0.2.1")))
            { BaseAddress = new Uri("https://localhost") };
        Assert.Equal(HttpStatusCode.NotFound, (await remote.GetAsync("/demo")).StatusCode);
    }
}
