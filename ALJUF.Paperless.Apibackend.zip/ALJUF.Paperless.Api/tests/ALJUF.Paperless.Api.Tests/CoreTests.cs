using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.DependencyInjection;
using ALJUF.Paperless;
using SkiaSharp;
using Xunit;
using ZXing;

namespace ALJUF.Paperless.Tests;

public sealed class TestClock : TimeProvider
{
    public DateTimeOffset Current { get; set; } = new(2026, 10, 26, 10, 0, 0, TimeSpan.Zero);
    public override DateTimeOffset GetUtcNow() => Current;
}
public sealed class Harness : IDisposable
{
    public readonly string DirectoryPath = Path.Combine(Path.GetTempPath(), "ALJUF-tests-" + Guid.NewGuid().ToString("N"));
    public readonly TestClock Clock = new();
    public Settings Settings { get; }
    public IUnitOfWork Store { get; }
    public ReviewedCreateUrlService CreateUrls { get; }
    public ReviewedTempUrlService TempUrls { get; }
    public ReviewedUpdateUrlService Updates { get; }
    private readonly UrlPolicyService policies;
    private readonly ReviewedUrlPolicy reviewed;
    public Reply Metadata(string id,string owner) => Store.Read(tx=>reviewed.Reply(policies.Owned(tx,id,owner)));
    public ILifecycleService Lifecycle { get; }
    public IPublicAccessService Access { get; }
    public TargetResolver Targets { get; }
    public ReviewedGenerateQrService Qr { get; }
    private readonly ServiceProvider services;
    public static byte[] Pdf => Encoding.ASCII.GetBytes("%PDF-1.4\n1 0 obj<</Type /Catalog>>endobj\n%%EOF\n");
    public Harness(IIntegrations? integrations = null)
    {
        Settings = new Settings
        {
            PublicOrigin = "https://paperless.example.invalid", DataDirectory = DirectoryPath,
            ClientPurposes = new() { ["client"] = ["PUBLIC", "PRIVATE", "SIGNED"] },
            Purposes = new()
            {
                ["PUBLIC"] = new() { Anonymous = true, CustomerBound = false, Immutable = false, AuthPolicies = ["none"], MaximumExpirySeconds = 86400 },
                ["PRIVATE"] = new() { Immutable = false, AuthPolicies = ["id4"], MaximumExpirySeconds = 86400 },
                ["SIGNED"] = new() { Immutable = true, AuthPolicies = ["id4"] }
            },
            Authentication = new()
            {
                ["none"] = new() { Type = AuthenticationType.NoAuth },
                ["id4"] = new() { Type = AuthenticationType.IDVerify4Digit, MaxAttempts = 5, Provider = "fixture" }
            },
            RedirectOrigins = ["https://documents.example.invalid"],
            Backends = new() { ["ecm"] = new() { BaseUri = "https://ecm.example.invalid", PathPrefix = "/documents/" }, ["portal"] = new() { BaseUri = "https://documents.example.invalid", PathPrefix = "/portal/" } }
        };
        Directory.CreateDirectory(DirectoryPath);
        var collection = new ServiceCollection();
        collection.AddDataProtection().SetApplicationName("Paperless.Tests").PersistKeysToFileSystem(new DirectoryInfo(Path.Combine(DirectoryPath, "keys")));
        collection.AddLogging(); collection.AddHttpClient(); services = collection.BuildServiceProvider();
        Store = new SqliteUnitOfWork(Settings, services.GetRequiredService<IDataProtectionProvider>());
        Targets = new TargetResolver(Settings, services.GetRequiredService<IHttpClientFactory>());
        integrations ??= new DevelopmentIntegrations();
        policies = new UrlPolicyService(Store, Settings, integrations, Clock);
        reviewed = new ReviewedUrlPolicy(Settings, policies, Targets, integrations);
        CreateUrls = new ReviewedCreateUrlService(policies, reviewed);
        TempUrls = new ReviewedTempUrlService(Settings, policies, reviewed);
        Updates = new ReviewedUpdateUrlService(policies, reviewed, Targets);
        Lifecycle = new LifecycleService(policies);
        Access = new PublicAccessService(Store, policies, Settings, integrations, Targets);
        Qr = new ReviewedGenerateQrService(Store, policies, Settings);
    }
    public static ReviewedTarget Content(byte[]? bytes=null) {
        bytes ??= Pdf; return new(Content:new(Convert.ToBase64String(bytes),"application/pdf","Quotation.pdf",Convert.ToHexString(SHA256.HashData(bytes))));
    }
    public ReviewedCreateUrlRequest Request(bool protect=false,string? document=null) => new(UrlMode.Content,protect?"PRIVATE":"PUBLIC",
        new("LOS","QUOTATION","q-demo",document??Guid.NewGuid().ToString("N"),"r1"),new("0000000123"),Clock.Current.AddMinutes(5),
        AuthenticationType:protect?AuthenticationType.IDVerify4Digit:AuthenticationType.NoAuth,Target:Content());
    public async Task<ReviewedUrlResource> Create(ReviewedCreateUrlRequest? r=null,bool temporary=false) {
        var reply=await CreateUrls.Create("client",Guid.NewGuid().ToString("N"),r??Request(),default);
        var resource=Json.Decode<ReviewedUrlResource>(reply.Body.GetRawText());
        if(temporary)resource=Json.Decode<ReviewedUrlResource>((await TempUrls.Create("client",Guid.NewGuid().ToString("N"),new(resource.UrlId),default)).Body.GetRawText());
        return resource;
    }
    public static AccessSession Session(Reply r) => Json.Decode<AccessSession>(r.Body.GetRawText());
    public SqliteUnitOfWork Reopen() => new(Settings, DataProtectionProvider.Create(new DirectoryInfo(Path.Combine(DirectoryPath,"keys")), b=>b.SetApplicationName("Paperless.Tests")));
    public void Dispose()
    {
        services.Dispose(); SqliteConnection.ClearAllPools();
        if (Directory.Exists(DirectoryPath)) Directory.Delete(DirectoryPath, true);
    }
}
public sealed class CoreTests
{
    [Fact] public async Task DuplicateCreationReplaysWithoutNewResource()
    {
        using var h = new Harness(); var r = h.Request();
        var a = await h.CreateUrls.Create("client", "same-key", r, default);
        var b = await h.CreateUrls.Create("client", "same-key", r, default);
        Assert.Equal(a.Body.GetRawText(), b.Body.GetRawText());
        var error = await Assert.ThrowsAsync<ApiError>(() => h.CreateUrls.Create("client", "same-key", r with { Locale="ar" }, default));
        Assert.Equal("IDEMPOTENCY_CONFLICT", error.Code);
    }
    [Fact] public async Task ConcurrentCreationHasOneOutcome()
    {
        using var h = new Harness(); var r = h.Request();
        var replies = await Task.WhenAll(Enumerable.Range(0,8).Select(_ => Task.Run(() => h.CreateUrls.Create("client", "race", r, default))));
        Assert.Single(replies.Select(x=>x.Body.GetProperty("urlId").GetString()).Distinct());
    }
    [Fact] public async Task DurableStateSurvivesStoreReopenAndIsProtected()
    {
        using var h = new Harness(); var r = await h.Create();
        var reopened = h.Reopen();
        Assert.Equal(r.UrlId,reopened.Read(tx=>tx.Urls.Get(r.UrlId))!.Id);
        var connection = new SqliteConnection(new SqliteConnectionStringBuilder {DataSource=Path.Combine(h.DirectoryPath,"paperless.db")}.ToString());
        using (connection) { connection.Open(); using var cmd=connection.CreateCommand();cmd.CommandText="SELECT Payload FROM Records WHERE Kind='url'";
            var payload=Assert.IsType<byte[]>(cmd.ExecuteScalar());Assert.DoesNotContain(new Uri(r.PublicUrl).Segments.Last(),Encoding.UTF8.GetString(payload)); }
        Assert.Equal(r.UrlId, Json.Decode<ReviewedUrlResource>(h.Metadata(r.UrlId,"client").Body.GetRawText()).UrlId);
    }
    [Fact] public async Task UnknownOwnerCannotReadOrUpdate()
    {
        using var h = new Harness(); var r=await h.Create();
        Assert.Equal(404,Assert.Throws<ApiError>(()=>h.Metadata(r.UrlId,"other")).Status);
        Assert.Equal(404,(await Assert.ThrowsAsync<ApiError>(()=>h.Updates.Update("other","k","\"v1\"",new(r.UrlId,Status:UrlStatus.Inactive,ReasonCode:"TEST"),default))).Status);
    }
    [Fact] public async Task MissingAndStaleEtagsAreRejected()
    {
        using var h=new Harness();var r=await h.Create();
        Assert.Equal(428,(await Assert.ThrowsAsync<ApiError>(()=>h.Updates.Update("client","a",null,new(r.UrlId,Status:UrlStatus.Inactive,ReasonCode:"TEST"),default))).Status);
        await h.Updates.Update("client","b","\"v1\"",new(r.UrlId,Status:UrlStatus.Inactive,ReasonCode:"TEST"),default);
        Assert.Equal(412,(await Assert.ThrowsAsync<ApiError>(()=>h.Updates.Update("client","c","\"v1\"",new(r.UrlId,Status:UrlStatus.Active,ReasonCode:"TEST"),default))).Status);
    }
    [Fact] public async Task TemporaryExpiryIsExactAndCannotBeReactivated()
    {
        using var h=new Harness();var r=await h.Create(temporary:true);h.Clock.Current=r.ExpiresAt!.Value;
        Assert.Equal(UrlStatus.Expired,Json.Decode<ReviewedUrlResource>(h.Metadata(r.UrlId,"client").Body.GetRawText()).Status);
        Assert.Equal(409,(await Assert.ThrowsAsync<ApiError>(()=>h.Updates.Update("client","a","\"v1\"",new(r.UrlId,Status:UrlStatus.Active,ReasonCode:"TEST"),default))).Status);
        await Assert.ThrowsAsync<ApiError>(()=>h.Access.Landing(new Uri(r.PublicUrl).Segments.Last(),default));
    }
    [Fact] public async Task ExpiredChildCanBeReplacedWhileParentRemainsActive()
    {
        using var h=new Harness();var parent=await h.Create(h.Request() with{ExpiresAt=h.Clock.Current.AddMinutes(15)});
        var old=Json.Decode<ReviewedTempUrlResource>((await h.TempUrls.Create("client","first",new(parent.UrlId),default)).Body.GetRawText());
        h.Clock.Current=old.ExpiresAt;
        await Assert.ThrowsAsync<ApiError>(()=>h.Access.Landing(old.PublicUrl.Split('/').Last(),default));
        var fresh=Json.Decode<ReviewedTempUrlResource>((await h.TempUrls.Create("client","second",new(parent.UrlId),default)).Body.GetRawText());
        Assert.NotEqual(old.UrlId,fresh.UrlId);Assert.Equal(h.Clock.Current.AddMinutes(5),fresh.ExpiresAt);
    }
    [Theory]
    [InlineData("https://evil.example.invalid/x")]
    [InlineData("//evil.example.invalid/x")]
    [InlineData("/documents/../secret")]
    [InlineData("/documents/%2e%2e/secret")]
    [InlineData("/documents/%252e%252e/secret")]
    public void RewriteRejectsEscapingPaths(string path)
    {
        using var h=new Harness();Assert.Throws<ApiError>(()=>h.Targets.Validate(UrlMode.RewriteUrl,new(BackendProfileId:"ecm",Url:path)));
    }
    [Fact] public void BaseUrlRemainsUnderRegisteredBase()
    {
        using var h=new Harness();Assert.Equal("https://documents.example.invalid/portal/doc",h.Targets.Validate(UrlMode.BaseUrl,new(BackendProfileId:"portal",Url:"/portal/doc")).AbsoluteUri);
    }
    [Fact] public async Task ThreeTargetModesCreateAndUpdate()
    {
        using var h=new Harness();
        foreach(var mode in new[]{UrlMode.RedirectUrl,UrlMode.RewriteUrl,UrlMode.BaseUrl}) {
            var target=mode==UrlMode.RewriteUrl?new ReviewedTarget("/documents/doc","ecm"):new ReviewedTarget("/portal/doc","portal");
            var created=await h.Create(h.Request() with{Mode=mode,Target=target});
            var updated=await h.Updates.Update("client",Guid.NewGuid().ToString(),"\"v1\"",new(created.UrlId,mode,target,DocumentRevision:"r2"),default);
            Assert.Equal("\"v2\"",updated.ETag);
        }
    }
    [Fact] public async Task InvalidFileDoesNotPublishOrOverwrite()
    {
        using var h=new Harness();var r=await h.Create();
        await Assert.ThrowsAsync<ApiError>(()=>h.Updates.Update("client","bad","\"v1\"",new(r.UrlId,UrlMode.Content,Harness.Content(Encoding.UTF8.GetBytes("not PDF")),DocumentRevision:"r2"),default));
        Assert.Equal("\"v1\"",h.Metadata(r.UrlId,"client").ETag);
    }
    [Fact] public async Task ImmutableSignedContentCannotBeReplaced()
    {
        using var h=new Harness();var r=await h.Create(h.Request(true) with{PurposeCode="SIGNED"});
        var error=await Assert.ThrowsAsync<ApiError>(()=>h.Updates.Update("client","replace","\"v1\"",new(r.UrlId,UrlMode.Content,Harness.Content(),DocumentRevision:"r2"),default));
        Assert.Equal("IMMUTABLE_RESOURCE",error.Code);
    }
    [Fact] public async Task NoAuthCannotBeAppliedToPrivatePurpose()
    {
        using var h=new Harness();var e=await Assert.ThrowsAsync<ApiError>(()=>h.Create(h.Request(true) with {AuthenticationType=AuthenticationType.NoAuth}));
        Assert.Equal("AUTH_POLICY_NOT_ALLOWED",e.Code);
    }
    [Fact] public async Task PrivateSessionRequiresCorrectEvidenceAndBothCookies()
    {
        using var h=new Harness();var r=await h.Create(h.Request(true));
        var started=await h.Access.Start(new(new Uri(r.PublicUrl).Segments.Last()),"start","browser",default);
        var s=Harness.Session(started);var flow=started.Cookies!.Single().Value;
        await Assert.ThrowsAsync<ApiError>(()=>h.Access.Download(s.SessionId,flow,null,default));
        await Assert.ThrowsAsync<ApiError>(()=>h.Access.Status(s.SessionId,"wrong",default));
        var verified=await h.Access.Verify(s.SessionId,flow,"verify",new(new(IdLast4:"0123")),default);
        Assert.Equal(SessionState.Authorized,Harness.Session(verified).State);
        var download=await h.Access.Download(s.SessionId,flow,verified.Cookies!.Single().Value,default);
        Assert.Equal(Harness.Pdf,download.Bytes);
    }
    [Fact] public async Task AttemptsAreAtomicAcrossSessionsAndRestart()
    {
        using var h=new Harness();var r=await h.Create(h.Request(true));
        var token=new Uri(r.PublicUrl).Segments.Last();
        var sessions=new List<(string Id,string Cookie)>();
        for(int i=0;i<5;i++){var a=await h.Access.Start(new(token),"start-"+i,"browser",default);sessions.Add((Harness.Session(a).SessionId,a.Cookies!.Single().Value));}
        await Task.WhenAll(sessions.Select((s,i)=>Task.Run(()=>h.Access.Verify(s.Id,s.Cookie,"bad-"+i,new(new(IdLast4:"9999")),default))));
        Assert.Equal(5,h.Store.Read(tx=>tx.Urls.Get(r.UrlId))!.FailedAttempts);
        var e=await Assert.ThrowsAsync<ApiError>(()=>h.Access.Start(new(token),"new","browser",default));Assert.Equal(429,e.Status);
        await h.Qr.Generate("client",new(r.UrlId,UrlKind.Regular,SizePx:512),default);
        Assert.Equal(5,h.Store.Read(tx=>tx.Urls.Get(r.UrlId))!.FailedAttempts);
    }
    [Fact] public async Task RevocationBlocksAlreadyAuthorizedSessionAndCannotBeUndone()
    {
        using var h=new Harness();var r=await h.Create();
        var started=await h.Access.Start(new(new Uri(r.PublicUrl).Segments.Last()),"start","browser",default);var s=Harness.Session(started);
        var flow=started.Cookies!.Single(c=>c.Name.Contains("-flow-",StringComparison.Ordinal)).Value;
        var auth=started.Cookies!.Single(c=>c.Name.Contains("-auth-",StringComparison.Ordinal)).Value;
        await h.Lifecycle.Lifecycle("client",new("event",r.UrlId,"Cancelled",2));
        await h.Lifecycle.Lifecycle("client",new("old",r.UrlId,"Superseded",1));
        await Assert.ThrowsAsync<ApiError>(()=>h.Access.Download(s.SessionId,flow,auth,default));
        await Assert.ThrowsAsync<ApiError>(()=>h.Updates.Update("client","activate","\"v2\"",new(r.UrlId,Status:UrlStatus.Active,ReasonCode:"TEST"),default));
    }
    [Fact] public async Task QrPngDecodesToExactUrlWithAndWithoutIcon()
    {
        using var h=new Harness();var r=await h.Create();
        using var bmp=new SKBitmap(32,32);using(var canvas=new SKCanvas(bmp)){canvas.Clear(SKColors.Teal);}
        var icon=Path.Combine(h.DirectoryPath,"icon.png");using(var image=SKImage.FromBitmap(bmp))using(var data=image.Encode(SKEncodedImageFormat.Png,100)){File.WriteAllBytes(icon,data.ToArray());}
        h.Settings.Icons["test-icon"]=icon;
        foreach(var asset in new string?[]{null,"test-icon"})
        {
            var (bytes,contentType)=await h.Qr.Generate("client",new(r.UrlId,UrlKind.Regular,SizePx:512,IconAssetId:asset),default);Assert.Equal("image/png",contentType);
            using var decoded=SKBitmap.Decode(bytes);var pixels=new byte[decoded.Width*decoded.Height*3];
            for(int y=0;y<decoded.Height;y++)for(int x=0;x<decoded.Width;x++){var color=decoded.GetPixel(x,y);var i=(y*decoded.Width+x)*3;pixels[i]=color.Red;pixels[i+1]=color.Green;pixels[i+2]=color.Blue;}
            var reader=new BarcodeReaderGeneric();var result=reader.Decode(pixels,decoded.Width,decoded.Height,RGBLuminanceSource.BitmapFormat.RGB24);
            Assert.NotNull(result);Assert.Equal(r.PublicUrl,result.Text);
        }
        var svg=await h.Qr.Generate("client",new(r.UrlId,UrlKind.Regular,"svg",512,IconAssetId:"test-icon"),default);
        Assert.Contains("data:image/png;base64,",Encoding.UTF8.GetString(svg.Bytes));
        Assert.DoesNotContain("<script",Encoding.UTF8.GetString(svg.Bytes));
        Assert.Equal("\"v1\"",h.Metadata(r.UrlId,"client").ETag);
    }
}
