using System.Net;
using System.Text;
using System.Text.Json;
using ALJUF.Paperless;
using Xunit;

namespace ALJUF.Paperless.Tests;
public sealed class EcmWrapperTests
{
    private static BackendProfile Profile()=>new(){BackendType="EcmWrapper",AuthType="SessionToken",WrapperContract="GetPdf",BaseUri="https://wrapper.example.invalid",PathPrefix="/documents/",
        LoginPath="/session/login",UsernameField="userName",PasswordField="password",Username="synthetic-user",Password="synthetic-password",TokenJsonPath="session.token",TokenHeaderName="X-Session-Token"};
    private static UrlRecord Document()=>new(){Request=new(UrlMode.RewriteUrl,"PUBLIC",new("FS","Document","1","1","1"),null,"none",null,Target:new("ecm-wrapper","/documents/1"))};
    [Fact] public async Task LoginThenDocumentUsesReturnedTokenAndNotBasicAuthentication()
    {
        var factory=new Factory();var settings=new Settings{Backends=new(){["ecm-wrapper"]=Profile()}};
        var bytes=await new TargetResolver(settings,factory).Fetch(Document(),default);
        Assert.Equal(Harness.Pdf,bytes);Assert.Equal(2,factory.Handler.Calls);Assert.Equal("paperless-backend:ecm-wrapper",factory.Name);
    }
    [Fact] public async Task FailedLoginCannotFetchDocument()
    {
        var factory=new Factory();factory.Handler.Fail=true;var settings=new Settings{Backends=new(){["ecm-wrapper"]=Profile()}};
        Assert.Equal("BACKEND_AUTHENTICATION_FAILED",(await Assert.ThrowsAsync<ApiError>(()=>new TargetResolver(settings,factory).Fetch(Document(),default))).Code);
        Assert.Equal(1,factory.Handler.Calls);
    }
    [Fact] public async Task LoginCannotLeaveConfiguredBackendAndMissingTokenCannotAuthorize()
    {
        var profile=Profile();profile.LoginPath="//other.example.invalid/login";using var client=new HttpClient(new Handler());using var request=new HttpRequestMessage(HttpMethod.Get,"https://wrapper.example.invalid/documents/1");
        await Assert.ThrowsAsync<ApiError>(()=>EcmWrapperAuthentication.Authenticate(client,profile,request,default));
        profile=Profile();profile.TokenJsonPath="missing.token";
        await Assert.ThrowsAsync<ApiError>(()=>EcmWrapperAuthentication.Authenticate(client,profile,request,default));
        Assert.False(request.Headers.Contains("X-Session-Token"));
    }
    private sealed class Factory:IHttpClientFactory
    {
        public readonly Handler Handler=new();public string? Name;
        public HttpClient CreateClient(string name){Name=name;return new HttpClient(Handler,false);}
    }
    private sealed class Handler:HttpMessageHandler
    {
        public int Calls;public bool Fail;
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)
        {
            Calls++;Assert.Null(request.Headers.Authorization);
            if(request.Method==HttpMethod.Post)
            {
                Assert.Equal("https://wrapper.example.invalid/session/login",request.RequestUri!.AbsoluteUri);
                using var json=JsonDocument.Parse(await request.Content!.ReadAsStringAsync(ct));
                Assert.Equal("synthetic-user",json.RootElement.GetProperty("userName").GetString());Assert.Equal("synthetic-password",json.RootElement.GetProperty("password").GetString());
                return new(Fail?HttpStatusCode.Unauthorized:HttpStatusCode.OK){Content=new StringContent("{\"session\":{\"token\":\"synthetic-token\"}}",Encoding.UTF8,"application/json")};
            }
            Assert.Equal("synthetic-token",request.Headers.GetValues("X-Session-Token").Single());
            var response=new HttpResponseMessage(HttpStatusCode.OK){Content=new ByteArrayContent(Harness.Pdf)};response.Content.Headers.ContentType=new("application/pdf");return response;
        }
    }
}
