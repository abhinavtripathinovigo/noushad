using System.Net;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using ALJUF.Paperless;
using Xunit;

namespace ALJUF.Paperless.Tests;

public sealed class BackendAuthenticationTests
{
    private static BackendProfile CertificateProfile(string eku="1.3.6.1.5.5.7.3.2",bool expired=false)
    {
        using var rsa=RSA.Create(2048);
        var request=new CertificateRequest("CN=synthetic-paperless-client",rsa,HashAlgorithmName.SHA256,RSASignaturePadding.Pkcs1);
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.DigitalSignature,true));
        request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension(new OidCollection{new Oid(eku)},false));
        using var certificate=request.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-2),DateTimeOffset.UtcNow.AddDays(expired?-1:1));
        const string password="synthetic-pässword";
        return new BackendProfile{BackendType="FS",AuthType="ClientCertificate",BaseUri="https://FS.example.invalid",
            ClientCertificateBase64=Convert.ToBase64String(certificate.Export(X509ContentType.Pfx,password)),
            ClientCertificatePasswordBase64=Convert.ToBase64String(Encoding.UTF8.GetBytes(password))};
    }
    [Fact] public void CertificateIsLoadedAndAttachedOnlyToItsOwnHandler()
    {
        var profile=CertificateProfile();
        using var loaded=BackendAuthentication.LoadCertificate(profile);Assert.True(loaded.HasPrivateKey);
        using var handler=Assert.IsAssignableFrom<HttpClientHandler>(BackendAuthentication.CreateHandler(profile));
        Assert.Single(handler.ClientCertificates);Assert.Equal(ClientCertificateOption.Manual,handler.ClientCertificateOptions);
        Assert.False(handler.AllowAutoRedirect);Assert.False(handler.UseCookies);Assert.True(handler.CheckCertificateRevocationList);
        Assert.Null(handler.ServerCertificateCustomValidationCallback);
        using var gateway=Assert.IsAssignableFrom<HttpClientHandler>(BackendAuthentication.CreateHandler(new(){BackendType="ApiGateway",AuthType="APIKey",BaseUri="https://gateway.example.invalid"}));
        Assert.Empty(gateway.ClientCertificates);
        using var message=new HttpRequestMessage(HttpMethod.Get,profile.BaseUri);BackendAuthentication.ApplyHeaders(profile,message);
        Assert.Null(message.Headers.Authorization);Assert.False(message.Headers.Contains("X-Api-Key"));
    }
    [Theory]
    [InlineData("BasicAuth")]
    [InlineData("NoAuth")]
    [InlineData("APIKey")]
    public void FSRejectsEveryNonCertificateAuthMode(string auth)
        =>Assert.Equal("BACKEND_CONFIGURATION_INVALID",Assert.Throws<ApiError>(()=>BackendAuthentication.Validate(new(){BackendType="FS",AuthType=auth,BaseUri="https://FS.example.invalid"})).Code);

    [Fact] public void InvalidCertificateInputsFailWithoutExposingValues()
    {
        var profile=CertificateProfile();profile.ClientCertificatePasswordBase64=Convert.ToBase64String(Encoding.UTF8.GetBytes("wrong"));
        var error=Assert.Throws<ApiError>(()=>BackendAuthentication.LoadCertificate(profile));Assert.Equal("CLIENT_CERTIFICATE_INVALID",error.Code);
        Assert.DoesNotContain(profile.ClientCertificateBase64!,error.Message);
        profile.ClientCertificateBase64="invalid-base64";Assert.Throws<ApiError>(()=>BackendAuthentication.LoadCertificate(profile));
        profile=CertificateProfile();profile.ClientCertificatePasswordBase64="/w==";Assert.Throws<ApiError>(()=>BackendAuthentication.LoadCertificate(profile));
        profile=CertificateProfile();using(var cert=BackendAuthentication.LoadCertificate(profile))profile.ClientCertificateBase64=Convert.ToBase64String(cert.Export(X509ContentType.Cert));
        Assert.Throws<ApiError>(()=>BackendAuthentication.LoadCertificate(profile));
    }
    [Fact] public void ExpiredAndServerOnlyCertificatesAreRejected()
    {
        Assert.Throws<ApiError>(()=>BackendAuthentication.LoadCertificate(CertificateProfile(expired:true)));
        Assert.Throws<ApiError>(()=>BackendAuthentication.LoadCertificate(CertificateProfile("1.3.6.1.5.5.7.3.1")));
    }
    [Fact] public void GatewayRequiresKeyAndWrapperRequiresExplicitContract()
    {
        var profile=new BackendProfile{BackendType="ApiGateway",AuthType="APIKey",BaseUri="https://gateway.example.invalid"};
        using var request=new HttpRequestMessage();Assert.Throws<ApiError>(()=>BackendAuthentication.ApplyHeaders(profile,request));
        profile.ApiKey="synthetic-only-key";BackendAuthentication.ApplyHeaders(profile,request);Assert.Equal(profile.ApiKey,request.Headers.GetValues("X-Api-Key").Single());
        profile.AuthType="NoAuth";Assert.Throws<ApiError>(()=>BackendAuthentication.Validate(profile));
        profile=new(){BackendType="EcmWrapper",BaseUri="https://wrapper.example.invalid"};Assert.Throws<ApiError>(()=>BackendAuthentication.Validate(profile));
        profile.WrapperContract="GetPdf";profile.AuthType="NoAuth";Assert.Throws<ApiError>(()=>BackendAuthentication.Validate(profile));
        profile.AuthType="SessionToken";BackendAuthentication.Validate(profile);
    }
    [Fact] public async Task FetchUsesSelectedGatewayClientAndNeverFollowsOtherOrigins()
    {
        var profile=new BackendProfile{BackendType="ApiGateway",AuthType="APIKey",ApiKey="synthetic-key",BaseUri="https://gateway.example.invalid",PathPrefix="/documents/"};
        var settings=new Settings{Backends=new(){["gateway"]=profile}};var factory=new RecordingFactory();var resolver=new TargetResolver(settings,factory);
        var record=new UrlRecord{Request=new(UrlMode.RewriteUrl,"PUBLIC",new("FS","Document","1","1","1"),null,"none",null,Target:new("gateway","/documents/1"))};
        Assert.Equal(Harness.Pdf,await resolver.Fetch(record,default));Assert.Equal("paperless-backend:gateway",factory.Name);
        Assert.Equal(profile.ApiKey,factory.Handler.Key);Assert.Equal("https://gateway.example.invalid/documents/1",factory.Handler.Url);
        record.Request=record.Request with{Target=new("gateway","https://other.example.invalid/documents/1")};
        await Assert.ThrowsAsync<ApiError>(()=>resolver.Fetch(record,default));Assert.Equal(1,factory.Handler.Calls);
    }
    private sealed class RecordingFactory:IHttpClientFactory
    {
        public string? Name;public readonly RecordingHandler Handler=new();
        public HttpClient CreateClient(string name){Name=name;return new HttpClient(Handler,false);}
    }
    private sealed class RecordingHandler:HttpMessageHandler
    {
        public string? Key,Url;public int Calls;
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct)
        {
            Calls++;Key=request.Headers.GetValues("X-Api-Key").Single();Url=request.RequestUri!.AbsoluteUri;
            var reply=new HttpResponseMessage(HttpStatusCode.OK){Content=new ByteArrayContent(Harness.Pdf)};
            reply.Content.Headers.ContentType=new("application/pdf");return Task.FromResult(reply);
        }
    }
}
