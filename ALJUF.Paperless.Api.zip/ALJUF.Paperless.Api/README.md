# ALJUF Paperless — reviewed-only solution v0.5.0

This delivery contains one management implementation: the reviewed JSON APIs. The previous management controllers, services, DTOs, multipart parser, creation workflow and old QR validation branch are removed. The retained reviewed filenames identify the implementation being delivered.

## Run in Visual Studio

Open `ALJUF.Paperless.sln`, set the API project as startup project, select **Paperless Browser Demo**, and press F5. The project targets .NET 10 and requires that SDK and the ASP.NET development certificate. Swagger UI assets are bundled; no Swagger package installation is needed.

- Demo: `https://localhost:7243/demo`
- Swagger: `https://localhost:7243/swagger`
- OpenAPI: `https://localhost:7243/swagger/reviewed/swagger.json`

The demo creates a regular parent through `ReviewedCreateUrlService`, creates a temporary child through `ReviewedTempUrlService`, and shows the actual QR. Authenticate with synthetic ID evidence **0123**, then click **Stamp document**. Open or optionally download the stamped copy. The original stays in storage; the stamped copy is generated in the browser and is not persisted to ECM. Localhost links work on the presentation computer, not on a separate phone.

The default temporary duration is five minutes. Authentication sessions have their own configured lifetime. Expired/denied access cannot retrieve the PDF for stamping. Use unsigned, unencrypted synthetic PDFs. The server and stamped-output size limits remain enforced.

## Development API key

Add `DevelopmentApiKey` under the existing `Paperless` object in `src/ALJUF.Paperless.Api/appsettings.Development.json` and set your private value of at least 32 characters, or configure it through Visual Studio User Secrets. Restart, then enter that value in Swagger Authorize for `X-Development-Api-Key`. Never commit a real key.

If this setting is omitted, the Browser Demo profile generates an in-memory key at startup. The demo calls services internally and needs no key entered in the browser. Production uses JWT bearer authentication and configured scopes; the development key is not a production authentication mechanism.

## Management endpoints

| Operation | Endpoint | Controller / service |
|---|---|---|
| Create URL | POST /v2/urls | ReviewedCreateUrlController / ReviewedCreateUrlService |
| Update URL | PATCH /v2/urls | ReviewedUpdateUrlController / ReviewedUpdateUrlService |
| Temporary URL | POST /v2/temp-urls | ReviewedCreateTempUrlController / ReviewedTempUrlService |
| Generate QR | POST /v2/qr-codes | ReviewedGenerateQrController / ReviewedGenerateQrService |
| Read metadata | GET /v2/urls/{id} | ReviewedMetadataController / ReviewedUrlPolicy |

Mutation requests require `Idempotency-Key`; updates also require the current ETag in `If-Match`. JSON samples are in `samples/reviewed-v2`. Substitute actual returned IDs and current expiry values. GenerateQR uses the new temporary ID, never the parent ID for a temporary QR. Its size is in pixels; omitted size defaults to 50, and an insufficient PNG size returns `QR_SIZE_TOO_SMALL`. Use a larger value such as 300 when testing a secure URL.

## Supporting modules retained

Public `/u/` and `/t/` pages, `/public/v1/access-sessions` endpoints, provider callbacks, lifecycle events, health, authentication, storage, integration adapters and shared domain logic remain required. Their independent `/public/v1` and `/internal/v1` versions do not represent the removed `/v1` management API. Swagger lists 14 controller operations: five reviewed management operations and nine supporting operations.

`Shared/Domain/DocumentDefinition.cs` and `DocumentTarget.cs` are internal normalized storage/adapter models. They are not old HTTP contracts. The request and response contracts exposed to management clients are the reviewed contracts only. Each API retains its own controller and service files; common repository interfaces and SQLite implementations are shared.

## Compatibility and deployment

This release deliberately removes `/v1/urls`, `/v1/temp-urls`, `/v1/qr-codes` and the old per-field update routes. Existing callers of those endpoints must migrate to `/v2` and its reviewed JSON. Previous delivery ZIPs remain available separately; they are not included in this project.

A separate `data-reviewed-only-v05` directory is used for local data. Do not point this version at a previous demo database without a migration review: obsolete destination representations have been removed. The reviewed API payloads remain unchanged. Interface workbook v0.5's legacy compatibility references and code mapping need to be updated if this becomes its implementation baseline.

The backend URLs in Development are placeholders. Real ECM, identity, malware scanning, integration grants and approved logo assets still need configuration. SQLite and local protected storage are a single-node reference design. This release does not implement the additional proposed production services or persist the browser-stamped PDF in ECM.

See `docs/VALIDATION.md`, `docs/REMOVED_LEGACY_FILES.md` and `docs/ADAPTERS.md`. Browser visual testing remains pending because automated browser launch was unavailable in this environment.
