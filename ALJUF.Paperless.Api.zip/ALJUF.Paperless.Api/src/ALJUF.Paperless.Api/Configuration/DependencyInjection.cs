using System.Net;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Options;
using ALJUF.Paperless;

namespace ALJUF.Paperless;

public static class DependencyInjection
{
    public static void AddPaperless(this WebApplicationBuilder builder)
    {
        builder.Logging.ClearProviders();
        builder.Logging.AddJsonConsole();
        var settings = builder.Configuration.GetSection("Paperless").Get<Settings>() ?? new Settings();
        var fixtures = builder.Environment.IsDevelopment() && settings.EnableDevelopmentFixtures;
        if (fixtures && builder.Configuration.GetValue<bool>("Paperless:BrowserDemo") && string.IsNullOrEmpty(settings.DevelopmentApiKey))
            settings.DevelopmentApiKey = Convert.ToHexString(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32));
        if (settings.EnableDevelopmentFixtures && !builder.Environment.IsDevelopment()) throw new InvalidOperationException("Development fixtures cannot run outside Development.");
        if (fixtures && (settings.DevelopmentApiKey?.Length ?? 0) < 32) throw new InvalidOperationException("Set a development-only API key of at least 32 characters.");
        if (!fixtures && (string.IsNullOrWhiteSpace(settings.JwtAuthority) || string.IsNullOrWhiteSpace(settings.JwtAudience)))
            throw new InvalidOperationException("Configure the JWT authority and audience.");
        if (!Uri.TryCreate(settings.PublicOrigin, UriKind.Absolute, out var publicOrigin) || publicOrigin.Scheme != "https"
            || publicOrigin.AbsolutePath != "/" || publicOrigin.Query.Length > 0 || publicOrigin.Fragment.Length > 0 || publicOrigin.UserInfo.Length > 0)
            throw new InvalidOperationException("PublicOrigin must be an HTTPS origin without a path, query, user information or fragment.");
        if (settings.MaxFileBytes is < 1024 or > 20*1024*1024 || settings.SessionSeconds is < 30 or > 600 || settings.DependencyTimeoutSeconds is < 1 or > 30
            || settings.IdempotencyHours is < 1 or > 168 || settings.Authentication.Values.Any(p => p.MaxAttempts is < 1 or > 20))
            throw new InvalidOperationException("Invalid configured resource limits.");
        settings.DataDirectory = Path.GetFullPath(settings.DataDirectory, builder.Environment.ContentRootPath);
        if (settings.TemporaryUrlDefaultMinutes < 1 || settings.TemporaryUrlDefaultMinutes > settings.TemporaryUrlMaximumMinutes
            || settings.TemporaryUrlMaximumMinutes > 10080 || settings.QrDefaultSizePx < 1
            || settings.QrDefaultSizePx > settings.QrMaximumSizePx || settings.QrMaximumSizePx > 4096)
            throw new InvalidOperationException("Invalid reviewed URL duration or QR size configuration.");
        builder.Services.AddSingleton<ReviewedUrlPolicy>();
        builder.Services.AddSingleton<ReviewedCreateUrlService>();
        builder.Services.AddSingleton<ReviewedUpdateUrlService>();
        builder.Services.AddSingleton<ReviewedTempUrlService>();
        builder.Services.AddSingleton(settings);
        builder.Services.AddSingleton(TimeProvider.System);
        var keyDirectory = new DirectoryInfo(Path.Combine(settings.DataDirectory, "keys")); keyDirectory.Create();
        var protection = builder.Services.AddDataProtection().SetApplicationName("ALJUF.Paperless.Api").PersistKeysToFileSystem(keyDirectory);
        if (!string.IsNullOrWhiteSpace(settings.KeyCertificatePath))
            protection.ProtectKeysWithCertificate(X509CertificateLoader.LoadPkcs12FromFile(settings.KeyCertificatePath, settings.KeyCertificatePassword));
        else if (!fixtures && !builder.Environment.IsEnvironment("Testing"))
            throw new InvalidOperationException("Configure a certificate to protect the persisted Data Protection keys before using real customer data.");
        builder.Services.AddSingleton<IUnitOfWork, SqliteUnitOfWork>();
        builder.Services.AddSingleton<UrlPolicyService>();
        builder.Services.AddSingleton<TargetResolver>();
        builder.Services.AddSingleton<ILifecycleService, LifecycleService>();
        builder.Services.AddSingleton<ReviewedGenerateQrService>();
        builder.Services.AddSingleton<IPublicAccessService, PublicAccessService>();
        builder.Services.AddControllers();
        if (fixtures) builder.Services.AddSingleton<IIntegrations, DevelopmentIntegrations>();
        else builder.Services.AddSingleton<IIntegrations, HttpIntegrations>();
        builder.Services.AddHttpClient("dependencies", c => { c.Timeout = TimeSpan.FromSeconds(settings.DependencyTimeoutSeconds); c.MaxResponseContentBufferSize = 1024*1024; })
            .ConfigurePrimaryHttpMessageHandler(() => new SocketsHttpHandler { AllowAutoRedirect = false, UseCookies = false, MaxConnectionsPerServer = 16 });
        builder.Services.AddAuthentication(fixtures ? "Development" : JwtBearerDefaults.AuthenticationScheme)
            .AddScheme<AuthenticationSchemeOptions, DevelopmentHandler>("Development", _ => {})
            .AddJwtBearer(o => { o.Authority = settings.JwtAuthority; o.Audience = settings.JwtAudience; o.RequireHttpsMetadata = true; o.MapInboundClaims = false; });
        builder.Services.AddAuthorization(o =>
        {
            foreach (var scope in new[] { "url:create", "url:read", "url:update", "qr:generate", "auth:callback", "url:lifecycle" })
                o.AddPolicy(scope, p => p.RequireAuthenticatedUser().RequireAssertion(c => c.User.FindAll("scope").Any(x => x.Value.Split(' ').Contains(scope))));
        });
        builder.Services.AddAntiforgery(o => { o.HeaderName = "X-CSRF-TOKEN"; o.Cookie.Name = "__Host-ALJUF-csrf";
            o.Cookie.SecurePolicy = CookieSecurePolicy.Always; o.Cookie.SameSite = SameSiteMode.Strict; o.Cookie.Path = "/"; });
        builder.Services.Configure<FormOptions>(o => { o.MultipartBodyLengthLimit = settings.MaxFileBytes + 65536; o.MemoryBufferThreshold = settings.MaxFileBytes + 65536; o.ValueLengthLimit = 32768; });
        builder.WebHost.ConfigureKestrel(o => o.Limits.MaxRequestBodySize = settings.MaxFileBytes * 4L / 3 + 65536);
        builder.Services.AddRateLimiter(o =>
        {
            o.RejectionStatusCode = 429;
            o.GlobalLimiter = PartitionedRateLimiter.CreateChained(PartitionedRateLimiter.Create<HttpContext, string>(context =>
                RateLimitPartition.GetFixedWindowLimiter(context.User.FindFirst("client_id")?.Value ?? context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
                    _ => new FixedWindowRateLimiterOptions { PermitLimit = 120, Window = TimeSpan.FromMinutes(1), QueueLimit = 0 })),
                PartitionedRateLimiter.Create<HttpContext, string>(_ => RateLimitPartition.GetConcurrencyLimiter("global",
                    _ => new ConcurrencyLimiterOptions { PermitLimit = 8, QueueLimit = 0 })));
            o.OnRejected = async (c, token) => { c.HttpContext.Response.Headers.RetryAfter = "60";
                await c.HttpContext.Response.WriteAsJsonAsync(new { code = "RATE_LIMITED", message = "Retry later.", correlationId = c.HttpContext.TraceIdentifier }, token); };
        });
    }
}
